# Google Search Console — AG9 v6 English

- Canonical site: https://ag9v4.ag9.workers.dev/
- Sitemap: https://ag9v4.ag9.workers.dev/sitemap.xml
- The Google verification meta token that existed in the supplied English homepage was preserved. Because the canonical host has changed from the originally configured sitemap host, confirm the property in Search Console after deployment. Generate a fresh HTML meta token if Google does not accept the preserved token.
- This package does not have access to your Google account and cannot submit the sitemap or request indexing on your behalf.

After deploying the files, verify the URL-prefix property in Search Console, submit the sitemap above in the Sitemaps report, and optionally use URL Inspection for the home page.
