# AG9 v6 — English

Static HTML/CSS/JavaScript portfolio. No build step or package manager is required.

## Pages
- `index.html` — Home
- `page/ag9-museum.html` — Museum and honors
- `page/support.html` — Support and contact

## v6 updates
- Added the supplied AG9 brand image as a circular profile mark before the AG9 wordmark in the navigation header on all three pages.
- Replaced the footer social destinations with the six current links supplied by the owner.
- Updated all visible and code-comment version labels from previous release to v6.
- Corrected canonical URLs and Open Graph URLs to the live English deployment host: `https://ag9v4.ag9.workers.dev`.
- Added reciprocal English/Persian `hreflang` alternates, Twitter card metadata, consistent Open Graph image metadata, and page-level Schema.org JSON-LD.
- Rebuilt `sitemap.xml` with all three canonical pages and bilingual alternates.
- Updated `robots.txt` and added `llms.txt` to make public site information easier for supported AI search crawlers to discover. Search/training crawler permissions are separated: search bots are allowed; model-training bots are disallowed by default.

## Social links
- X: https://x.com/ASTRArya11
- Telegram: https://t.me/Astra_1105
- Instagram: https://www.instagram.com/astra_201105?igsh=aWtrcmJ5N283N3Vp
- LinkedIn: https://www.linkedin.com/in/arya-ghavami-4ba5a23a3?utm_source=share_via&utm_content=profile&utm_medium=member_android
- Astra Land: https://astrarya11.carrd.co
- GitHub: https://github.com/a7rya1390-ux

## Assets and résumé
- Brand image: `pic/Lucid_Origin_A_luxurious_epic_logo_for_the_brand_AG9_set_again_1.jpg`
- Résumé PDF: `resume/Arya_Ghavami_Resume.pdf`
- Résumé preview: `pic/resume-preview.webp`

## Deployment
Upload the contents of this folder to the English Cloudflare Worker/Pages project currently served at `https://ag9v4.ag9.workers.dev/`. Keep the folder structure intact.

## Google Search Console
See `GOOGLE_SEARCH_CONSOLE.md`. The existing English verification meta token is retained, but must be confirmed for the current hostname in Search Console. The sitemap is ready at `https://ag9v4.ag9.workers.dev/sitemap.xml`; it still must be submitted from the owner's Search Console account. Sitemap submission is a discovery hint, not a guarantee of indexing.

## Important
`llms.txt` and crawler rules improve machine readability and permit supported AI search crawlers to fetch public pages, but they do not register the site in every AI product or guarantee recommendations.
