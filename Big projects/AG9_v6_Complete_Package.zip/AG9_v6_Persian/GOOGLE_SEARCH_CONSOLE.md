# Google Search Console — AG9 v6 Persian

- Canonical site: https://ag9v4fa.ag9.workers.dev/
- Sitemap: https://ag9v4fa.ag9.workers.dev/sitemap.xml
- The supplied Persian homepage did not contain a Google Search Console HTML verification token. A valid token must be generated from your own Search Console property; none has been invented or copied from the English site because those tokens may be property-specific. Paste the generated meta tag into the homepage head after Google provides it.
- This package does not have access to your Google account and cannot submit the sitemap or request indexing on your behalf.

After deploying the files, verify this URL-prefix property in Search Console, submit the sitemap above in the Sitemaps report, and optionally use URL Inspection for the home page.
