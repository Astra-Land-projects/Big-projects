# AG9 v6 — فارسی (RTL)

وب‌سایت استاتیک HTML/CSS/JavaScript است و به مرحله‌ی build یا نصب package نیاز ندارد.

## صفحات
- `index.html` — خانه
- `page/ag9-museum.html` — موزه و افتخارات
- `page/support.html` — پشتیبانی و راه‌های تماس

## تغییرات نسخه‌ی ۶
- تصویر اصلی برند AG9 به‌صورت دایره‌ای پیش از نوشته‌ی AG9 در هدر هر سه صفحه قرار گرفت.
- شش لینک جدید شبکه‌های اجتماعی در فوتر جایگزین مقصدهای قبلی شدند.
- برچسب‌های نسخه و توضیحات کد از نسخه‌ی قبلی به v6 به‌روزرسانی شدند.
- Canonical و Open Graph بر اساس دامنه‌ی فعال نسخه‌ی فارسی تنظیم شدند: `https://ag9v4fa.ag9.workers.dev`.
- hreflang دوطرفه‌ی فارسی/انگلیسی، کارت Twitter، تصویر Open Graph و داده‌های ساختاریافته‌ی Schema.org اضافه شدند.
- `sitemap.xml` با هر سه صفحه و پیوندهای زبان جایگزین بازسازی شد.
- `robots.txt` به‌روزرسانی و `llms.txt` برای خوانایی بهتر اطلاعات عمومی سایت توسط خزنده‌های جست‌وجوی هوش مصنوعی اضافه شد. خزنده‌های جست‌وجو مجازند؛ خزنده‌های آموزش مدل به‌صورت پیش‌فرض مسدودند.

## لینک‌های شبکه‌های اجتماعی
- ایکس: https://x.com/ASTRArya11
- تلگرام: https://t.me/Astra_1105
- اینستاگرام: https://www.instagram.com/astra_201105?igsh=aWtrcmJ5N283N3Vp
- لینکدین: https://www.linkedin.com/in/arya-ghavami-4ba5a23a3?utm_source=share_via&utm_content=profile&utm_medium=member_android
- Astra Land: https://astrarya11.carrd.co
- گیت‌هاب: https://github.com/a7rya1390-ux

## فایل‌ها
- تصویر برند: `pic/Lucid_Origin_A_luxurious_epic_logo_for_the_brand_AG9_set_again_1.jpg`
- رزومه: `resume/Arya_Ghavami_Resume_FA.pdf`
- پیش‌نمایش رزومه: `pic/resume-preview.webp`

## انتشار
محتویات این پوشه را در پروژه‌ی Cloudflare Worker/Pages نسخه‌ی فارسی که اکنون روی `https://ag9v4fa.ag9.workers.dev/` در دسترس است بارگذاری کن و ساختار پوشه‌ها را حفظ کن.

## Google Search Console
راهنمای `GOOGLE_SEARCH_CONSOLE.md` را ببین. نسخه‌ی فارسی در نسخه‌ی قبلی تگ تأیید گوگل نداشت؛ باید از حساب Search Console خودت برای این دامنه یک token جداگانه بگیری و تگ را در بخش head فایل `index.html` قرار بدهی. نقشه‌ی سایت آماده است: `https://ag9v4fa.ag9.workers.dev/sitemap.xml`؛ ثبت آن در حساب گوگل باید توسط مالک سایت انجام شود. ارسال سایت‌مپ فقط راهنمای کشف صفحات است و ایندکس شدن را تضمین نمی‌کند.

## نکته
فایل `llms.txt` و تنظیمات خزنده‌ها خوانایی سایت برای ابزارهای پشتیبانی‌شده را بهتر می‌کنند، اما ثبت خودکار در همه‌ی محصولات هوش مصنوعی یا معرفی قطعی سایت را تضمین نمی‌کنند.
