// ==========================================================================
// AG9 v6 (Persian) — Shared behavior: mobile nav, scroll progress, reveal
// animations, support widget, AI assistant (client-side, rule-based), hero
// slider with gold dust, honors, résumé spotlight stage.
// ==========================================================================

// --------------------------------------------------------------------------
// EASY-EDIT ZONE #1 — Honors (Museum page).
// To add a new honor, copy one object below and edit it.
// `icon` is a short emoji shown until you have a real photo — once you have
// one, set `image: "../pic/your-file.jpg"` instead and it will be used.
// --------------------------------------------------------------------------
const AG9_ACHIEVEMENTS = [
  { icon: "🎓", image: null, title: "+۲۰۰ مدرک", desc: "مجموعه‌ای متنوع از مدارک در برنامه‌نویسی، هوش مصنوعی و موارد دیگر." },
  { icon: "💻", image: null, title: "+۱۰۰۰ پروژه", desc: "از آزمایش‌های کوچک تا اپلیکیشن‌های کامل — همیشه در حال ساختن." },
  { icon: "🏢", image: null, title: "۵ برند", desc: "آسترا، AG9 و بیشتر — ساختن یک اکوسیستم، نه فقط چند پروژه." },
  { icon: "🌐", image: null, title: "فول‌استک و مهندس هوش مصنوعی", desc: "طراحی، ساخت و عرضه‌ی محصولات کامل از ابتدا تا انتها." },
  { icon: "🗣️", image: null, title: "زبان‌ها", desc: "مسلط به انگلیسی، در حال یادگیری عربی و اسپانیایی." },
  { icon: "⭐", image: null, title: "بی‌شمار موفقیت کوچک", desc: "هر قدم کوچک در این مسیر — همه‌شون در کنار هم معنا پیدا می‌کنن." },
];

// --------------------------------------------------------------------------
// EASY-EDIT ZONE #2 — Support AI assistant replies.
// Each entry: [ [trigger keywords...], "reply text" ]. First match wins.
// --------------------------------------------------------------------------
const AG9_AI_RULES = [
  [["سلام", "درود", "hi", "hello"], "سلام! من دستیار AG9 هستم. درباره‌ی موزه، پروژه‌ها، برندها یا راه ارتباط مستقیم با آریا بپرس."],
  [["موزه", "افتخار", "مدرک", "جایزه"], "صفحه‌ی AG9 Museum رو از منو ببین — مدارک، پروژه‌ها و دستاوردهای دیگه اونجاست."],
  [["پروژه", "کار", "نمونه کار"], "AG9 نماینده‌ی بیش از ۱۰۰۰ پروژه‌ست! صفحه‌ی موزه بهترین‌هاشون رو نشون می‌ده."],
  [["آسترا", "astra"], "آسترا برند اصلیه — می‌تونی ازش دیدن کنی: arya8.pythonanywhere.com"],
  [["تماس", "تلگرام", "ایمیل", "ارتباط"], "می‌تونی مستقیم از تلگرام (@Arya11MG) یا ایمیل (a7rya1390@gmail.com) پیام بدی — هر دو توی صفحه‌ی پشتیبانی هستن."],
  [["کی", "درباره", "سن", "آریا"], "AG9 برند شخصی آریا قوامیه — برنامه‌نویس فول‌استک و مهندس هوش مصنوعی."],
];
const AG9_AI_DEFAULT = "دقیق متوجه نشدم — می‌تونی درباره‌ی موزه، پروژه‌ها، آسترا، یا راه تماس با آریا بپرسی.";

function ag9RuleReply(message) {
  const text = message.toLowerCase();
  for (const [keywords, reply] of AG9_AI_RULES) {
    if (keywords.some(k => text.includes(k))) return reply;
  }
  return AG9_AI_DEFAULT;
}

const AG9_SLIDE_LABEL = "رفتن به اسلاید";

document.addEventListener('DOMContentLoaded', () => {

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
  const hasIO = 'IntersectionObserver' in window;

  /* ---- Mobile nav toggle ---- */
  const navToggle = document.querySelector('.nav-toggle');
  const navLinks = document.querySelector('.nav-links');
  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      navLinks.classList.toggle('open');
    });
    navLinks.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => navLinks.classList.remove('open'));
    });
  }

  /* ---- Scroll progress bar, nav state, hero parallax ---- */
  const progressBar = document.createElement('div');
  progressBar.className = 'scroll-progress';
  progressBar.setAttribute('aria-hidden', 'true');
  document.body.appendChild(progressBar);

  const siteNav = document.querySelector('.site-nav');
  const slider = document.querySelector('.hero-slider');
  let scrollTicking = false;

  function onScroll() {
    if (scrollTicking) return;
    scrollTicking = true;
    requestAnimationFrame(() => {
      scrollTicking = false;
      const y = window.scrollY;
      const max = document.documentElement.scrollHeight - window.innerHeight;
      progressBar.style.setProperty('--p', max > 0 ? Math.min(1, y / max).toFixed(4) : '0');
      if (siteNav) siteNav.classList.toggle('is-scrolled', y > 24);
      if (slider && !reduceMotion && y < window.innerHeight * 1.2) {
        slider.style.setProperty('--sy', String(Math.round(y)));
      }
    });
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('resize', onScroll);
  onScroll();

  /* ---- Helpers ---- */
  function observeOnce(elements, onEnter, threshold) {
    if (!elements.length) return;
    if (!hasIO) { elements.forEach(onEnter); return; }
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          onEnter(entry.target);
          io.unobserve(entry.target);
        }
      });
    }, { threshold: threshold || 0.15 });
    elements.forEach(el => io.observe(el));
  }

  /* Gold dust particles drawn on a canvas. `init(p, w, h, first)` places a
     particle, `step(p, dt, w, h)` moves it. Runs only while `active` is true. */
  function createDust(canvas, opts) {
    const ctx = canvas.getContext('2d');
    if (!ctx) return { setActive() {} };
    let w = 0, h = 0, raf = 0, last = 0, active = false;
    let parts = [];

    function resize() {
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = rect.width; h = rect.height;
      canvas.width = Math.max(1, Math.round(w * dpr));
      canvas.height = Math.max(1, Math.round(h * dpr));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      parts = [];
      for (let i = 0; i < opts.count; i++) {
        const p = { t: Math.random() * 6.28 };
        opts.init(p, w, h, true);
        parts.push(p);
      }
    }

    function frame(now) {
      if (!active) return;
      const dt = Math.min(0.05, (now - last) / 1000 || 0.016);
      last = now;
      ctx.clearRect(0, 0, w, h);
      for (const p of parts) {
        p.t += dt;
        opts.step(p, dt, w, h);
        const a = p.a * (0.55 + 0.45 * Math.sin(p.t * p.tw));
        ctx.beginPath();
        ctx.fillStyle = 'rgba(' + opts.rgb + ',' + a.toFixed(3) + ')';
        ctx.arc(p.x, p.y, p.r, 0, 6.2832);
        ctx.fill();
      }
      raf = requestAnimationFrame(frame);
    }

    function setActive(on) {
      if (on === active) return;
      active = on;
      cancelAnimationFrame(raf);
      if (on) { last = performance.now(); raf = requestAnimationFrame(frame); }
    }

    let resizeTimer = 0;
    window.addEventListener('resize', () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(resize, 150);
    });
    document.addEventListener('visibilitychange', () => { if (document.hidden) setActive(false); });
    resize();
    return { setActive, resize };
  }

  /* Pointer-driven effects: spotlight position and optional 3D tilt. */
  function bindPointerFx(elements, tiltDeg) {
    if (!finePointer) return;
    elements.forEach(el => {
      el.addEventListener('pointermove', (e) => {
        const r = el.getBoundingClientRect();
        const x = e.clientX - r.left;
        const y = e.clientY - r.top;
        el.style.setProperty('--mx', x + 'px');
        el.style.setProperty('--my', y + 'px');
        if (tiltDeg && !reduceMotion) {
          el.style.setProperty('--ry', (((x / r.width) - 0.5) * 2 * tiltDeg).toFixed(2) + 'deg');
          el.style.setProperty('--rx', (((0.5 - (y / r.height))) * 2 * tiltDeg).toFixed(2) + 'deg');
        }
      });
      el.addEventListener('pointerleave', () => {
        el.style.setProperty('--rx', '0deg');
        el.style.setProperty('--ry', '0deg');
      });
    });
  }

  /* ---- Support widget: panel + AI chat (client-side, no server needed) ---- */
  const guideCircle = document.querySelector('.guide-circle');
  const guideTooltip = document.querySelector('.guide-tooltip');
  const supportPanel = document.querySelector('.support-panel');
  const openAiBtn = document.querySelector('.open-ai-chat');
  const aiChatBox = document.querySelector('.ai-chat-box');
  const aiChatForm = document.querySelector('.ai-chat-form');
  const aiChatInput = document.querySelector('.ai-chat-input');
  const aiChatLog = document.querySelector('.ai-chat-log');

  function setPanel(open) {
    if (!supportPanel || !guideCircle) return;
    supportPanel.classList.toggle('is-open', open);
    guideCircle.setAttribute('aria-expanded', open ? 'true' : 'false');
  }

  if (guideCircle) {
    guideCircle.setAttribute('aria-expanded', 'false');
    guideCircle.addEventListener('touchstart', () => {
      if (guideTooltip) {
        guideTooltip.classList.add('is-visible');
        setTimeout(() => guideTooltip.classList.remove('is-visible'), 1800);
      }
    }, { passive: true });

    guideCircle.addEventListener('click', (e) => {
      e.preventDefault();
      setPanel(!(supportPanel && supportPanel.classList.contains('is-open')));
    });

    document.addEventListener('click', (e) => {
      if (!supportPanel || !supportPanel.classList.contains('is-open')) return;
      if (supportPanel.contains(e.target) || guideCircle.contains(e.target)) return;
      setPanel(false);
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') setPanel(false);
    });
  }

  if (openAiBtn && aiChatBox) {
    openAiBtn.addEventListener('click', () => {
      aiChatBox.classList.toggle('is-open');
      if (aiChatBox.classList.contains('is-open') && aiChatInput) aiChatInput.focus();
    });
  }

  if (aiChatForm && aiChatInput && aiChatLog) {
    aiChatForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const msg = aiChatInput.value.trim();
      if (!msg) return;

      const userMsg = document.createElement('div');
      userMsg.className = 'ai-msg user';
      userMsg.textContent = msg;
      aiChatLog.appendChild(userMsg);

      const botMsg = document.createElement('div');
      botMsg.className = 'ai-msg bot';
      botMsg.textContent = ag9RuleReply(msg);
      aiChatLog.appendChild(botMsg);

      aiChatInput.value = '';
      aiChatLog.scrollTop = aiChatLog.scrollHeight;
    });
  }

  /* ---- Render honors from AG9_ACHIEVEMENTS (Museum page only) ---- */
  const museumGrid = document.querySelector('.museum-grid');
  if (museumGrid) {
    AG9_ACHIEVEMENTS.forEach((item, index) => {
      const el = document.createElement('div');
      el.className = 'exhibit';
      el.style.setProperty('--i', String(index % 3));
      el.innerHTML = `
        <div class="exhibit-frame">${item.image ? `<img src="${item.image}" alt="${item.title}">` : item.icon}</div>
        <div class="plaque">${item.title}</div>
        <p class="exhibit-desc">${item.desc}</p>
      `;
      museumGrid.appendChild(el);
    });
    bindPointerFx(Array.from(museumGrid.querySelectorAll('.exhibit')), 7);
  }

  /* ---- Scroll reveal (honors, headings, cards) ---- */
  observeOnce(Array.from(document.querySelectorAll('.reveal, .exhibit')), (el) => {
    el.classList.add('is-visible');
  }, 0.15);

  /* ---- Cards: cursor spotlight ---- */
  bindPointerFx(Array.from(document.querySelectorAll('.card')), 0);

  /* ---- Magnetic buttons ---- */
  if (finePointer && !reduceMotion) {
    document.querySelectorAll('.btn').forEach(btn => {
      btn.addEventListener('pointermove', (e) => {
        const r = btn.getBoundingClientRect();
        btn.style.setProperty('--bx', (((e.clientX - r.left) / r.width - 0.5) * 12).toFixed(1) + 'px');
        btn.style.setProperty('--by', (((e.clientY - r.top) / r.height - 0.5) * 8).toFixed(1) + 'px');
      });
      btn.addEventListener('pointerleave', () => {
        btn.style.setProperty('--bx', '0px');
        btn.style.setProperty('--by', '0px');
      });
    });
  }

  /* ---- Count-up for the About Me stats (keeps prefix/suffix and digit style) ---- */
  const PERSIAN_DIGITS = '۰۱۲۳۴۵۶۷۸۹';
  function countUp(el) {
    const text = el.textContent;
    const m = text.match(/[0-9۰-۹]+/);
    if (!m) return;
    const persian = /[۰-۹]/.test(m[0]);
    const target = parseInt(m[0].replace(/[۰-۹]/g, d => PERSIAN_DIGITS.indexOf(d)), 10);
    if (!isFinite(target)) return;
    const pre = text.slice(0, m.index);
    const post = text.slice(m.index + m[0].length);
    const duration = 1700;
    const t0 = performance.now();
    function tick(now) {
      const k = Math.min(1, (now - t0) / duration);
      const eased = k === 1 ? 1 : 1 - Math.pow(2, -10 * k);
      let value = String(Math.round(target * eased));
      if (persian) value = value.replace(/[0-9]/g, d => PERSIAN_DIGITS[d]);
      el.textContent = pre + value + post;
      if (k < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }
  if (!reduceMotion) {
    observeOnce(Array.from(document.querySelectorAll('.about-stats')), (wrap) => {
      wrap.querySelectorAll('.about-stat h3').forEach(countUp);
    }, 0.4);
  }

  /* ---- Hero slider (Home page only) ---- */
  if (slider) {
    const slides = Array.from(slider.querySelectorAll('.slide'));
    const dotsWrap = slider.querySelector('.slide-dots');
    const INTERVAL_MS = 6000; // <-- change this number to adjust auto-advance speed
    let current = 0;
    let timer = null;

    slides.forEach((_, i) => {
      const dot = document.createElement('button');
      dot.classList.add('slide-dot');
      dot.setAttribute('aria-label', `${AG9_SLIDE_LABEL} ${i + 1}`);
      if (i === 0) dot.classList.add('is-active');
      dot.addEventListener('click', () => goTo(i));
      dotsWrap.appendChild(dot);
    });
    const dots = Array.from(dotsWrap.querySelectorAll('.slide-dot'));

    function goTo(index) {
      slides[current].classList.remove('is-active');
      dots[current].classList.remove('is-active');
      current = index;
      slides[current].classList.add('is-active');
      void dots[current].offsetWidth; // restart the progress-fill animation
      dots[current].classList.add('is-active');
      resetTimer();
    }

    function next() {
      goTo((current + 1) % slides.length);
    }

    function resetTimer() {
      clearInterval(timer);
      timer = setInterval(next, INTERVAL_MS);
    }

    if (slides.length > 1) {
      resetTimer();
    }

    /* Swipe support on touch screens */
    let touchX = null;
    slider.addEventListener('touchstart', (e) => { touchX = e.touches[0].clientX; }, { passive: true });
    slider.addEventListener('touchend', (e) => {
      if (touchX === null || slides.length < 2) return;
      const dx = e.changedTouches[0].clientX - touchX;
      touchX = null;
      if (Math.abs(dx) < 50) return;
      goTo(dx < 0 ? (current + 1) % slides.length : (current - 1 + slides.length) % slides.length);
    }, { passive: true });

    /* Cursor glow + gold dust over the hero */
    const glow = document.createElement('div');
    glow.className = 'hero-glow';
    glow.setAttribute('aria-hidden', 'true');
    slider.appendChild(glow);
    if (finePointer) {
      slider.addEventListener('pointermove', (e) => {
        const r = slider.getBoundingClientRect();
        glow.style.setProperty('--gx', (e.clientX - r.left) + 'px');
        glow.style.setProperty('--gy', (e.clientY - r.top) + 'px');
      });
    }

    if (!reduceMotion) {
      const dustCanvas = document.createElement('canvas');
      dustCanvas.className = 'hero-dust';
      dustCanvas.setAttribute('aria-hidden', 'true');
      slider.appendChild(dustCanvas);
      const heroDust = createDust(dustCanvas, {
        count: window.innerWidth < 700 ? 34 : 70,
        rgb: '232, 200, 120',
        init(p, w, h, first) {
          p.x = Math.random() * w;
          p.y = first ? Math.random() * h : h + 10;
          p.r = 0.6 + Math.random() * 1.8;
          p.vy = 10 + Math.random() * 26;
          p.sway = 6 + Math.random() * 18;
          p.a = 0.25 + Math.random() * 0.55;
          p.tw = 0.8 + Math.random() * 2.2;
          p.x0 = p.x;
        },
        step(p, dt, w, h) {
          p.y -= p.vy * dt;
          p.x = p.x0 + Math.sin(p.t * 0.6) * p.sway;
          if (p.y < -10) this.init(p, w, h, false);
        }
      });
      if (hasIO) {
        new IntersectionObserver((entries) => {
          heroDust.setActive(entries[0].isIntersecting);
        }, { threshold: 0.05 }).observe(slider);
      } else {
        heroDust.setActive(true);
      }
    }
  }

  /* ---- Résumé stage: the spotlight switches on when it scrolls into view ---- */
  const stageSection = document.querySelector('.resume-stage');
  if (stageSection) {
    const stage = stageSection.querySelector('.stage');
    const paper = stageSection.querySelector('.resume-paper');
    const dustCanvas = stageSection.querySelector('.stage-dust');
    bindPointerFx(paper ? [paper] : [], 5);

    let stageDust = null;
    if (dustCanvas && !reduceMotion) {
      dustCanvas.style.opacity = '0';
      dustCanvas.style.transition = 'opacity 2s ease 0.6s';
      const TAN = Math.tan(40 * Math.PI / 180);
      stageDust = createDust(dustCanvas, {
        count: window.innerWidth < 700 ? 40 : 90,
        rgb: '255, 236, 170',
        init(p, w, h, first) {
          const y = first ? Math.random() * h * 0.9 : Math.random() * 40;
          const half = TAN * y;
          p.y = y;
          p.x0 = w / 2 + (Math.random() * 2 - 1) * half;
          p.x = p.x0;
          p.r = 0.7 + Math.random() * 1.7;
          p.vy = 3 + Math.random() * 12;
          p.sway = 4 + Math.random() * 14;
          p.a = 0.2 + Math.random() * 0.6;
          p.tw = 0.8 + Math.random() * 2.4;
        },
        step(p, dt, w, h) {
          p.y += p.vy * dt;
          p.x = p.x0 + Math.sin(p.t * 0.5) * p.sway;
          if (p.y > h * 0.92 || Math.abs(p.x - w / 2) > TAN * p.y + 30) this.init(p, w, h, false);
        }
      });
    }

    function lightOn() {
      stageSection.classList.add('is-lit');
      if (stageDust) {
        stageDust.setActive(true);
        dustCanvas.style.opacity = '1';
      }
    }

    if (stage && hasIO) {
      const io = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting) {
          lightOn();
          io.disconnect();
        }
      }, { threshold: 0.3 });
      io.observe(stage);
    } else {
      lightOn();
    }
  }
});
