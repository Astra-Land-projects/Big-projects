"""allauth adapters that keep social sign-in consistent with Astra's consent flow."""
from django.conf import settings
from django.contrib import messages
from django.shortcuts import redirect
from django.utils import timezone
from allauth.account.adapter import DefaultAccountAdapter
from allauth.socialaccount.adapter import DefaultSocialAccountAdapter

try:
    from allauth.core.exceptions import ImmediateHttpResponse
except ImportError:  # pragma: no cover
    from allauth.exceptions import ImmediateHttpResponse

from .models import LegalAcceptance, Profile


class AstraAccountAdapter(DefaultAccountAdapter):
    def is_open_for_signup(self, request):
        return True


class AstraSocialAccountAdapter(DefaultSocialAccountAdapter):
    def _current_consent(self, request):
        consent = request.session.get("astra_legal_consent")
        if not isinstance(consent, dict):
            return False
        try:
            accepted_at = float(consent.get("accepted_at", 0))
        except (TypeError, ValueError):
            return False
        return (
            consent.get("terms_version") == settings.ASTRA_TERMS_VERSION
            and consent.get("privacy_version") == settings.ASTRA_PRIVACY_VERSION
            and 0 <= timezone.now().timestamp() - accepted_at <= 900
        )

    def is_open_for_signup(self, request, sociallogin):
        # Existing linked accounts can still sign in; new social registrations must pass
        # through the current, version-pinned Astra consent form before account creation.
        return self._current_consent(request)

    def save_user(self, request, sociallogin, form=None):
        user = super().save_user(request, sociallogin, form)
        Profile.objects.get_or_create(user=user)
        is_current = self._current_consent(request)
        consent = request.session.pop("astra_legal_consent", None)
        if is_current and isinstance(consent, dict):
            LegalAcceptance.objects.get_or_create(
                user=user,
                terms_version=consent["terms_version"],
                privacy_version=consent["privacy_version"],
            )
        return user

    def on_authentication_error(self, request, provider, *args, **kwargs):
        request.session.pop("astra_legal_consent", None)
        messages.error(request, "We could not sign you in with that provider. Please try again, or use your username and password.")
        raise ImmediateHttpResponse(redirect("login"))
