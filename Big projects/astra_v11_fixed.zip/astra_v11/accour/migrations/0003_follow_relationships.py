from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


def create_missing_profiles(apps, schema_editor):
    User = apps.get_model(*settings.AUTH_USER_MODEL.split("."))
    Profile = apps.get_model("accour", "Profile")
    user_ids = User.objects.filter(profile__isnull=True).values_list("pk", flat=True)
    Profile.objects.bulk_create(
        [Profile(user_id=user_id) for user_id in user_ids.iterator()],
        ignore_conflicts=True,
        batch_size=500,
    )


class Migration(migrations.Migration):
    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("accour", "0002_legal_acceptance"),
    ]

    operations = [
        migrations.CreateModel(
            name="Follow",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True, db_index=True)),
                ("follower", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="following_links", to=settings.AUTH_USER_MODEL)),
                ("following", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="follower_links", to=settings.AUTH_USER_MODEL)),
            ],
            options={"ordering": ["-created_at"]},
        ),
        migrations.AddConstraint(
            model_name="follow",
            constraint=models.UniqueConstraint(fields=("follower", "following"), name="unique_profile_follow_pair"),
        ),
        migrations.AddIndex(
            model_name="follow",
            index=models.Index(fields=["following", "created_at"], name="accour_following_created_idx"),
        ),
        migrations.AddIndex(
            model_name="follow",
            index=models.Index(fields=["follower", "created_at"], name="accour_follower_created_idx"),
        ),
        migrations.RunPython(create_missing_profiles, migrations.RunPython.noop),
    ]
