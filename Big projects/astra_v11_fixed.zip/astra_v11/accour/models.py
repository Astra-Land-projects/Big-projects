from django.conf import settings
from django.db import models

from core.validators import validate_image_file


class Profile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="profile")
    avatar = models.ImageField(upload_to="avatars/", blank=True, null=True, validators=[validate_image_file])
    banner = models.ImageField(upload_to="banners/", blank=True, null=True, validators=[validate_image_file])
    bio = models.TextField(max_length=300, blank=True)
    is_verified = models.BooleanField(
        default=False,
        help_text="Shows a blue verified checkmark next to this user's name on their Profile and on Astragram posts.",
    )

    def __str__(self):
        return f"Profile of {self.user}"


class Follow(models.Model):
    """A directed follow relationship: follower follows following."""
    follower = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="following_links")
    following = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="follower_links")
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ["-created_at"]
        constraints = [
            models.UniqueConstraint(fields=["follower", "following"], name="unique_profile_follow_pair"),
        ]
        indexes = [
            models.Index(fields=["following", "created_at"], name="accour_following_created_idx"),
            models.Index(fields=["follower", "created_at"], name="accour_follower_created_idx"),
        ]

    def clean(self):
        super().clean()
        if self.follower_id and self.follower_id == self.following_id:
            from django.core.exceptions import ValidationError
            raise ValidationError("You cannot follow your own account.")

    def __str__(self):
        return f"{self.follower} follows {self.following}"


class LegalAcceptance(models.Model):
    """Auditable record of the exact Terms and Privacy versions accepted by a member."""
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="legal_acceptances")
    terms_version = models.CharField(max_length=32)
    privacy_version = models.CharField(max_length=32)
    accepted_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-accepted_at"]
        constraints = [
            models.UniqueConstraint(
                fields=["user", "terms_version", "privacy_version"],
                name="unique_user_legal_versions",
            )
        ]

    def __str__(self):
        return f"{self.user} accepted legal documents {self.terms_version}/{self.privacy_version}"
