import io
import shutil
import tempfile

from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase, override_settings
from django.urls import reverse

from .models import LegalAcceptance, Profile

User = get_user_model()


class AutomaticAccountActivationTests(TestCase):
    def test_signup_creates_active_user_and_logs_them_in(self):
        response = self.client.post(
            reverse("login"),
            {
                "form_type": "signup",
                "username": "new_astra_member",
                "email": "member@example.com",
                "password1": "A-Long-Unique-Test-Password-2026!",
                "password2": "A-Long-Unique-Test-Password-2026!",
                "accept_legal": "on",
            },
        )
        user = User.objects.get(username="new_astra_member")
        self.assertTrue(user.is_active)
        self.assertTrue(Profile.objects.filter(user=user).exists())
        self.assertTrue(LegalAcceptance.objects.filter(user=user, terms_version="2026-11-12", privacy_version="2026-11-12").exists())
        self.assertEqual(int(self.client.session["_auth_user_id"]), user.pk)
        self.assertEqual(response.status_code, 302)

    def test_signup_requires_current_legal_consent(self):
        response = self.client.post(reverse("login"), {
            "form_type": "signup", "username": "no_consent", "email": "no-consent@example.com",
            "password1": "A-Long-Unique-Test-Password-2026!", "password2": "A-Long-Unique-Test-Password-2026!",
        })
        self.assertEqual(response.status_code, 200)
        self.assertFalse(User.objects.filter(username="no_consent").exists())
        self.assertContains(response, "Please accept the Terms")

    def test_social_consent_is_required_and_recorded_in_session(self):
        denied = self.client.post(reverse("social_login_consent", args=["google"]), {})
        self.assertEqual(denied.status_code, 302)
        self.assertNotIn("astra_legal_consent", self.client.session)
        accepted = self.client.post(reverse("social_login_consent", args=["google"]), {"accept_legal": "on"})
        self.assertEqual(accepted.status_code, 302)
        self.assertTrue(self.client.session.get("astra_legal_consent"))

    def test_login_returns_member_to_requested_page(self):
        User.objects.create_user(
            username="redirect_member",
            password="Another-Unique-Strong-Password-2026!",
        )
        response = self.client.post(
            reverse("login"),
            {
                "form_type": "login",
                "username": "redirect_member",
                "password": "Another-Unique-Strong-Password-2026!",
                "next": "/astragram/",
            },
        )
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, "/astragram/")

    def test_login_accepts_email_address(self):
        user = User.objects.create_user(
            username="email_login_member",
            email="login@example.com",
            password="Another-Unique-Strong-Password-2026!",
        )
        response = self.client.post(
            reverse("login"),
            {"form_type": "login", "username": "login@example.com", "password": "Another-Unique-Strong-Password-2026!"},
        )
        self.assertEqual(response.status_code, 302)
        self.assertEqual(int(self.client.session["_auth_user_id"]), user.pk)

    def test_astragram_feed_uses_profile_avatar_template(self):
        from astragram.models import Post

        user = User.objects.create_user(username="feed_member", password="Safe-test-password-2026!")
        Post.objects.create(author=user, caption="Astra feed smoke test")
        response = self.client.get("/astragram/")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Astra feed smoke test")
        self.assertContains(response, "astra-post-avatar")

    def test_admin_login_page_uses_custom_branding_template(self):
        response = self.client.get("/admin/login/")
        self.assertEqual(response.status_code, 200)


class LoginMessageAndSocialTests(TestCase):
    def test_login_shows_success_message_after_redirect(self):
        User.objects.create_user(username="msg_member", password="Another-Unique-Strong-Password-2026!")
        response = self.client.post(
            reverse("login"),
            {"form_type": "login", "username": "msg_member", "password": "Another-Unique-Strong-Password-2026!"},
            follow=True,
        )
        self.assertContains(response, "Login successful")

    def test_wrong_password_shows_error_and_stays_logged_out(self):
        User.objects.create_user(username="wrong_pw", password="Another-Unique-Strong-Password-2026!")
        response = self.client.post(
            reverse("login"), {"form_type": "login", "username": "wrong_pw", "password": "nope"}
        )
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "We could not sign you in")
        self.assertNotIn("_auth_user_id", self.client.session)

    @override_settings(GOOGLE_LOGIN_ENABLED=False, GITHUB_LOGIN_ENABLED=False)
    def test_social_buttons_are_friendly_when_keys_are_missing(self):
        response = self.client.get(reverse("login"))
        self.assertContains(response, reverse("social_unavailable", args=["google"]))
        follow = self.client.get(reverse("social_unavailable", args=["google"]), follow=True)
        self.assertEqual(follow.redirect_chain[-1][0], reverse("login"))
        self.assertContains(follow, "Google sign-in is not set up")

    @override_settings(GOOGLE_LOGIN_ENABLED=True, GITHUB_LOGIN_ENABLED=True)
    def test_social_buttons_use_allauth_when_keys_exist(self):
        response = self.client.get(reverse("login"))
        self.assertContains(response, reverse("social_login_consent", args=["google"]))
        self.assertContains(response, reverse("social_login_consent", args=["github"]))

    def test_allauth_default_pages_redirect_to_astra_login(self):
        for path in ("/accounts/login/", "/accounts/signup/"):
            with self.subTest(path=path):
                response = self.client.get(path)
                self.assertEqual(response.status_code, 302)
                self.assertEqual(response.url, reverse("login"))

    def test_cancelled_social_login_returns_to_login_with_message(self):
        response = self.client.get(reverse("social_cancelled"), follow=True)
        self.assertEqual(response.redirect_chain[-1][0], reverse("login"))
        self.assertContains(response, "cancelled")


_AVATAR_MEDIA = tempfile.mkdtemp()


@override_settings(MEDIA_ROOT=_AVATAR_MEDIA)
class ProfilePhotoSyncTests(TestCase):
    """The photo on every Astragram post is the member's Profile avatar - one source of truth."""

    @classmethod
    def tearDownClass(cls):
        super().tearDownClass()
        shutil.rmtree(_AVATAR_MEDIA, ignore_errors=True)

    @staticmethod
    def _png(name, color):
        from PIL import Image

        buffer = io.BytesIO()
        Image.new("RGB", (48, 48), color).save(buffer, "PNG")
        return SimpleUploadedFile(name, buffer.getvalue(), content_type="image/png")

    def test_new_avatar_appears_on_existing_posts_and_changes_with_profile(self):
        from astragram.models import Post

        user = User.objects.create_user(username="photo_member", password="Safe-test-password-2026!")
        self.client.force_login(user, backend="django.contrib.auth.backends.ModelBackend")
        Post.objects.create(author=user, caption="Photo sync post")

        before = self.client.get("/astragram/")
        self.assertContains(before, "astra-post-avatar")
        self.assertNotContains(before, "/media/avatars/")

        response = self.client.post(reverse("profile"), {"bio": "Hello", "avatar": self._png("first.png", "gold")})
        self.assertEqual(response.status_code, 302)
        first_url = Profile.objects.get(user=user).avatar.url
        self.assertContains(self.client.get("/astragram/"), first_url)

        self.client.post(reverse("profile"), {"bio": "Hello", "avatar": self._png("second.png", "navy")})
        second_url = Profile.objects.get(user=user).avatar.url
        self.assertNotEqual(first_url, second_url)
        feed = self.client.get("/astragram/")
        self.assertContains(feed, second_url)
        self.assertNotContains(feed, first_url)



class PolicyPageTests(TestCase):
    def test_policy_pages_show_current_version_and_links(self):
        terms = self.client.get(reverse("terms"))
        privacy = self.client.get(reverse("privacy"))
        self.assertEqual(terms.status_code, 200)
        self.assertEqual(privacy.status_code, 200)
        self.assertContains(terms, "Version: 2026-11-12")
        self.assertContains(privacy, "Version: 2026-11-12")
        login_page = self.client.get(reverse("login"))
        self.assertContains(login_page, reverse("terms"))
        self.assertContains(login_page, reverse("privacy"))

class FollowRelationshipTests(TestCase):
    def test_public_profile_follow_and_unfollow_counts(self):
        owner = User.objects.create_user(username="profile_owner", password="Safe-Test-Password-2026!")
        visitor = User.objects.create_user(username="profile_visitor", password="Safe-Test-Password-2026!")
        public_url = reverse("public_profile", args=[owner.username])
        self.assertContains(self.client.get(public_url), "Followers")

        self.client.force_login(visitor)
        response = self.client.post(reverse("toggle_follow", args=[owner.username]))
        self.assertEqual(response.status_code, 302)
        self.assertEqual(owner.follower_links.count(), 1)
        self.assertContains(self.client.get(public_url), "1")

        self.client.post(reverse("toggle_follow", args=[owner.username]))
        self.assertEqual(owner.follower_links.count(), 0)

    def test_follow_records_are_unique_and_self_follow_is_rejected(self):
        from .models import Follow
        owner = User.objects.create_user(username="follow_target", password="Safe-Test-Password-2026!")
        member = User.objects.create_user(username="follow_member", password="Safe-Test-Password-2026!")
        self.client.force_login(member)
        self.client.post(reverse("toggle_follow", args=[owner.username]))
        self.client.post(reverse("toggle_follow", args=[owner.username]))
        self.assertEqual(Follow.objects.filter(follower=member, following=owner).count(), 0)
        self.client.post(reverse("toggle_follow", args=[member.username]))
        self.assertFalse(Follow.objects.filter(follower=member, following=member).exists())

