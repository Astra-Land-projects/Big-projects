from django.conf import settings
from django.contrib import messages
from django.contrib.auth import authenticate, get_user_model, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from django.core.validators import validate_email
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.http import require_POST
from django.db import transaction

from core.models import HomeSlide
from awards.models import CompetitionAward

from .models import Follow, LegalAcceptance, Profile

User = get_user_model()


def _record_legal_acceptance(user):
    LegalAcceptance.objects.get_or_create(
        user=user,
        terms_version=settings.ASTRA_TERMS_VERSION,
        privacy_version=settings.ASTRA_PRIVACY_VERSION,
    )


def index(request):
    slides = HomeSlide.objects.filter(is_active=True)
    return render(request, "index.html", {"slides": slides})


def _safe_next_url(request):
    candidate = request.POST.get("next") or request.GET.get("next") or ""
    if candidate and url_has_allowed_host_and_scheme(
        candidate, allowed_hosts={request.get_host()}, require_https=request.is_secure()
    ):
        return candidate
    return "index"


def _create_profile_account(request):
    username = request.POST.get("username", "").strip()
    email = request.POST.get("email", "").strip()
    password1 = request.POST.get("password1", "")
    password2 = request.POST.get("password2", "")

    if request.POST.get("accept_legal") != "on":
        raise ValidationError("Please accept the Terms & Conditions and acknowledge the Privacy Policy before creating an account.")
    if not username or not password1 or not password2:
        raise ValidationError("Username and both password fields are required.")

    username_field = User._meta.get_field(User.USERNAME_FIELD)
    username = username_field.clean(username, None)
    if User.objects.filter(username__iexact=username).exists():
        raise ValidationError("That username is already in use. Please choose another one.")
    if email:
        validate_email(email)
        if User.objects.filter(email__iexact=email).exists():
            raise ValidationError("That email address is already connected to an account.")
    if password1 != password2:
        raise ValidationError("The passwords do not match.")

    candidate = User(username=username, email=email)
    validate_password(password1, user=candidate)
    with transaction.atomic():
        user = User.objects.create_user(username=username, email=email, password=password1, is_active=True)
        Profile.objects.get_or_create(user=user)
        _record_legal_acceptance(user)
    return user


def login_view(request):
    if request.user.is_authenticated:
        return redirect(_safe_next_url(request))

    active_tab = "login"
    next_url = _safe_next_url(request)
    if request.method == "POST":
        form_type = request.POST.get("form_type", "login")
        destination = next_url
        if form_type == "signup":
            active_tab = "signup"
            try:
                user = _create_profile_account(request)
            except ValidationError as exc:
                for error in exc.messages:
                    messages.error(request, error)
            else:
                login(request, user, backend="django.contrib.auth.backends.ModelBackend")
                messages.success(request, "Your account is ready. You are now logged in successfully!")
                return redirect(destination)
        else:
            identifier = request.POST.get("username", "").strip()
            password = request.POST.get("password", "")
            if not identifier or not password:
                messages.error(request, "Please enter your username or email and password.")
            else:
                account = User.objects.filter(username__iexact=identifier).first()
                if account is None and User.USERNAME_FIELD != "email":
                    account = User.objects.filter(email__iexact=identifier).first()
                login_name = account.get_username() if account else identifier
                user = authenticate(request, username=login_name, password=password)
                if user is not None and user.is_active:
                    Profile.objects.get_or_create(user=user)
                    login(request, user)
                    messages.success(request, "Login successful. Welcome back to Astra!")
                    return redirect(destination)
                messages.error(request, "We could not sign you in. Check your details or create an account.")

    return render(request, "astra_login2.html", {
        "active_tab": active_tab,
        "next_url": next_url,
        "google_login_enabled": getattr(settings, "GOOGLE_LOGIN_ENABLED", False),
        "github_login_enabled": getattr(settings, "GITHUB_LOGIN_ENABLED", False),
    })


PROVIDER_NAMES = {"google": "Google", "github": "GitHub"}


@require_POST
def social_login_consent(request, provider):
    if provider not in PROVIDER_NAMES:
        messages.error(request, "That sign-in provider is not supported.")
        return redirect("login")
    if request.POST.get("accept_legal") != "on":
        messages.error(request, "Please accept the Terms & Conditions and acknowledge the Privacy Policy to continue.")
        return redirect("login")
    request.session["astra_legal_consent"] = {
        "terms_version": settings.ASTRA_TERMS_VERSION,
        "privacy_version": settings.ASTRA_PRIVACY_VERSION,
        "accepted_at": timezone.now().timestamp(),
    }
    return redirect(f"/accounts/{provider}/login/")


def social_unavailable(request, provider):
    name = PROVIDER_NAMES.get(provider, "That provider")
    messages.info(request, f"{name} sign-in is not set up on this server yet. Please use your username and password for now.")
    return redirect("login")


def social_cancelled(request):
    request.session.pop("astra_legal_consent", None)
    messages.info(request, "Sign-in was cancelled. You can try again whenever you are ready.")
    return redirect("login")


def terms(request):
    version = settings.ASTRA_TERMS_VERSION
    return render(request, "legal/terms.html", {"policy_version": version, "policy_effective_date": version})


def privacy(request):
    version = settings.ASTRA_PRIVACY_VERSION
    return render(request, "legal/privacy.html", {"policy_version": version, "policy_effective_date": version})


def logout_view(request):
    logout(request)
    messages.success(request, "You have been logged out successfully.")
    return redirect("index")


def _profile_page_context(profile_user, viewer, can_edit=False):
    profile, _ = Profile.objects.get_or_create(user=profile_user)
    from astragram.models import Post
    from rank.models import RankPeriodPrize

    claimed_awards = CompetitionAward.objects.filter(
        user=profile_user, claimed_at__isnull=False
    ).order_by("-period_end", "-claimed_at")
    claimed_rank_prizes = RankPeriodPrize.objects.filter(
        user=profile_user, claimed_at__isnull=False
    ).order_by("-period_end", "-claimed_at")
    followers_qs = Follow.objects.filter(following=profile_user).select_related(
        "follower", "follower__profile"
    )
    following_qs = Follow.objects.filter(follower=profile_user).select_related(
        "following", "following__profile"
    )
    is_following = bool(
        viewer.is_authenticated
        and viewer.pk != profile_user.pk
        and Follow.objects.filter(follower=viewer, following=profile_user).exists()
    )
    return {
        "profile": profile,
        "profile_user": profile_user,
        "can_edit": can_edit,
        "is_following": is_following,
        "followers_count": followers_qs.count(),
        "following_count": following_qs.count(),
        "followers": followers_qs[:12],
        "following": following_qs[:12],
        "public_posts": Post.objects.filter(author=profile_user, is_visible=True)
            .select_related("author", "author__profile").order_by("-created_at")[:30],
        "public_posts_count": Post.objects.filter(author=profile_user, is_visible=True).count(),
        "claimed_awards": claimed_awards,
        "award_count": claimed_awards.count(),
        "claimed_rank_prizes": claimed_rank_prizes,
        "rank_prize_count": claimed_rank_prizes.count(),
    }


@login_required
def profile_view(request):
    profile, _ = Profile.objects.get_or_create(user=request.user)
    if request.method == "POST":
        profile.bio = request.POST.get("bio", "").strip()[:300]
        if request.FILES.get("avatar"):
            profile.avatar = request.FILES["avatar"]
        if request.FILES.get("banner"):
            profile.banner = request.FILES["banner"]
        try:
            profile.full_clean(exclude=["user"])
            profile.save()
        except ValidationError as exc:
            for error in exc.messages:
                messages.error(request, error)
        else:
            messages.success(request, "Profile updated successfully.")
            return redirect("profile")
    context = _profile_page_context(request.user, request.user, can_edit=True)
    return render(request, "astra_profile.html", context)


def public_profile(request, username):
    profile_user = get_object_or_404(User, username=username, is_active=True)
    context = _profile_page_context(profile_user, request.user, can_edit=False)
    return render(request, "astra_profile.html", context)


@login_required
@require_POST
def toggle_follow(request, username):
    profile_user = get_object_or_404(User, username=username, is_active=True)
    if profile_user.pk == request.user.pk:
        messages.info(request, "You cannot follow your own account.")
        return redirect("profile")

    relation = Follow.objects.filter(follower=request.user, following=profile_user)
    if relation.exists():
        relation.delete()
        messages.success(request, f"You unfollowed @{profile_user.username}.")
    else:
        Follow.objects.get_or_create(follower=request.user, following=profile_user)
        messages.success(request, f"You are now following @{profile_user.username}.")
    return redirect("public_profile", username=profile_user.username)
