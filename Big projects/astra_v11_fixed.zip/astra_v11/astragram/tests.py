from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from .models import Comment, Message, Post

User = get_user_model()


class AstragramModerationTests(TestCase):
    def setUp(self):
        self.author = User.objects.create_user(username="astra_author", password="Safe-Test-Password-2026!")
        self.reader = User.objects.create_user(username="astra_reader", password="Safe-Test-Password-2026!")

    def test_hidden_posts_and_comments_are_not_shown_in_feed(self):
        visible = Post.objects.create(author=self.author, caption="Visible post")
        hidden = Post.objects.create(author=self.author, caption="Hidden post", is_visible=False)
        Comment.objects.create(post=visible, user=self.reader, text="Visible comment")
        Comment.objects.create(post=visible, user=self.reader, text="Hidden comment", is_visible=False)
        response = self.client.get(reverse("astragram:feed"))
        self.assertContains(response, "Visible post")
        self.assertNotContains(response, "Hidden post")
        self.assertContains(response, "Visible comment")
        self.assertNotContains(response, "Hidden comment")

    def test_opening_a_chat_marks_incoming_messages_as_read(self):
        message = Message.objects.create(sender=self.author, recipient=self.reader, text="Hello")
        self.client.force_login(self.reader)
        inbox = self.client.get(reverse("astragram:inbox"))
        self.assertContains(inbox, "1")
        response = self.client.get(reverse("astragram:chat_with", args=[self.author.username]))
        self.assertEqual(response.status_code, 200)
        message.refresh_from_db()
        self.assertTrue(message.is_read)
        self.assertIsNotNone(message.read_at)

    def test_message_poll_only_returns_messages_for_the_two_participants(self):
        other = User.objects.create_user(username="third_member", password="Safe-Test-Password-2026!")
        Message.objects.create(sender=self.author, recipient=self.reader, text="Private hello")
        Message.objects.create(sender=self.author, recipient=other, text="Other chat")
        self.client.force_login(self.reader)
        response = self.client.get(reverse("astragram:poll_messages", args=[self.author.username]))
        self.assertEqual(response.status_code, 200)
        self.assertEqual([row["text"] for row in response.json()["messages"]], ["Private hello"])

    def test_post_author_name_and_avatar_open_public_profile(self):
        Post.objects.create(author=self.author, caption="Click through to profile")
        response = self.client.get(reverse("astragram:feed"))
        self.assertContains(response, reverse("public_profile", args=[self.author.username]))
        profile = self.client.get(reverse("public_profile", args=[self.author.username]))
        self.assertEqual(profile.status_code, 200)
        self.assertContains(profile, "Click through to profile")

    def test_member_search_and_message_send_and_poll_work(self):
        self.client.force_login(self.reader)
        search = self.client.get(reverse("astragram:inbox"), {"q": self.author.username})
        self.assertContains(search, reverse("astragram:chat_with", args=[self.author.username]))
        chat = self.client.get(reverse("astragram:chat_with", args=[self.author.username]))
        self.assertEqual(chat.status_code, 200)
        self.assertContains(chat, "beginning of your conversation")
        sent = self.client.post(reverse("astragram:send_message", args=[self.author.username]), {"text": "Astra message check"})
        self.assertEqual(sent.status_code, 200)
        self.assertTrue(sent.json()["ok"])
        self.client.force_login(self.author)
        received = self.client.get(reverse("astragram:poll_messages", args=[self.reader.username]), {"after": 0})
        self.assertEqual(received.status_code, 200)
        self.assertEqual(received.json()["messages"][0]["text"], "Astra message check")
        saved = Message.objects.get(text="Astra message check")
        self.assertTrue(saved.is_read)

    def test_member_cannot_follow_self_and_private_messages_stay_between_participants(self):
        self.client.force_login(self.author)
        before = self.client.post(reverse("toggle_follow", args=[self.author.username]))
        self.assertEqual(before.status_code, 302)
        from accour.models import Follow
        self.assertFalse(Follow.objects.exists())

