from django.urls import path

from . import views

app_name = "astragram"

urlpatterns = [
    path("", views.feed, name="feed"),
    path("post/new/", views.create_post, name="create_post"),
    path("post/<int:post_id>/like/", views.toggle_like, name="toggle_like"),
    path("post/<int:post_id>/comment/", views.add_comment, name="add_comment"),
    path("messages/", views.inbox, name="inbox"),
    path("messages/<str:username>/", views.chat_with, name="chat_with"),
    path("messages/<str:username>/send/", views.send_message, name="send_message"),
    path("messages/<str:username>/poll/", views.poll_messages, name="poll_messages"),
]
