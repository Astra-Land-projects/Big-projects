from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Prefetch, Q
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from awards.services import record_comment_score, record_like_score, record_post_score, remove_like_score
from .models import Comment, Like, Message, Post

User = get_user_model()


def feed(request):
    visible_comments = Comment.objects.filter(is_visible=True).select_related("user", "user__profile")
    posts = (
        Post.objects.filter(is_visible=True, author__is_active=True)
        .select_related("author", "author__profile")
        .prefetch_related("likes", Prefetch("comments", queryset=visible_comments, to_attr="visible_comments"))
        .annotate(visible_comment_count=Count("comments", distinct=True, filter=Q(comments__is_visible=True)))
    )
    liked_post_ids = set()
    if request.user.is_authenticated:
        liked_post_ids = set(Like.objects.filter(user=request.user, post__in=posts).values_list("post_id", flat=True))
    return render(request, "astragram/feed.html", {
        "posts": posts,
        "liked_post_ids": liked_post_ids,
        "unread_count": Message.objects.filter(recipient=request.user, is_read=False).count()
            if request.user.is_authenticated else 0,
    })


@login_required
@require_POST
def create_post(request):
    caption = request.POST.get("caption", "").strip()[:2000]
    image = request.FILES.get("image")
    if caption or image:
        post = Post.objects.create(author=request.user, caption=caption, image=image)
        earned = record_post_score(post)
        if earned:
            messages.success(request, "Your post is live! You earned 10 Astra Award points.")
        else:
            messages.success(request, "Your post is live! Your first three posts each day are eligible for points.")
    return redirect("astragram:feed")


@login_required
@require_POST
def toggle_like(request, post_id):
    post = get_object_or_404(Post, id=post_id, is_visible=True)
    like, created = Like.objects.get_or_create(post=post, user=request.user)
    if not created:
        remove_like_score(like)
        like.delete()
        liked = False
    else:
        record_like_score(like)
        liked = True
    return JsonResponse({"liked": liked, "like_count": post.like_count})


@login_required
@require_POST
def add_comment(request, post_id):
    post = get_object_or_404(Post, id=post_id, is_visible=True)
    text = request.POST.get("text", "").strip()[:500]
    if text:
        comment = Comment.objects.create(post=post, user=request.user, text=text)
        record_comment_score(comment)
        messages.success(request, "Comment added successfully.")
    return redirect("astragram:feed")


@login_required
def inbox(request):
    query = request.GET.get("q", "").strip()[:80]
    partner_ids = set(Message.objects.filter(sender=request.user).values_list("recipient_id", flat=True)) | set(
        Message.objects.filter(recipient=request.user).values_list("sender_id", flat=True)
    )
    partners = (
        User.objects.filter(id__in=partner_ids, is_active=True)
        .select_related("profile")
        .annotate(unread_count=Count(
            "sent_messages",
            filter=Q(sent_messages__recipient=request.user, sent_messages__is_read=False),
        ))
        .order_by("-unread_count", "username")
    )
    search_results = User.objects.none()
    if query:
        search_results = User.objects.filter(is_active=True, username__icontains=query).exclude(pk=request.user.pk).select_related("profile")[:20]
    unread_count = Message.objects.filter(recipient=request.user, is_read=False).count()
    return render(request, "astragram/inbox.html", {
        "partners": partners, "unread_count": unread_count,
        "query": query, "search_results": search_results,
    })


@login_required
def chat_with(request, username):
    other = get_object_or_404(User, username=username, is_active=True)
    if other.pk == request.user.pk:
        messages.info(request, "You cannot start a direct conversation with your own account.")
        return redirect("astragram:inbox")
    conversation_filter = (Q(sender=request.user, recipient=other) | Q(sender=other, recipient=request.user))
    Message.objects.filter(sender=other, recipient=request.user, is_read=False).update(
        is_read=True, read_at=timezone.now()
    )
    chat_messages = list(
        Message.objects.filter(conversation_filter).select_related("sender", "recipient").order_by("-created_at", "-id")[:150]
    )
    chat_messages.reverse()
    return render(request, "astragram/chat.html", {
        "other": other, "chat_messages": chat_messages,
        "unread_count": Message.objects.filter(recipient=request.user, is_read=False).count(),
    })


@login_required
@require_POST
def send_message(request, username):
    other = get_object_or_404(User, username=username, is_active=True)
    if other.pk == request.user.pk:
        return JsonResponse({"ok": False, "error": "self_message_not_allowed"}, status=400)
    text = request.POST.get("text", "").strip()[:1000]
    if not text:
        return JsonResponse({"ok": False, "error": "empty_message"}, status=400)
    message = Message.objects.create(sender=request.user, recipient=other, text=text)
    return JsonResponse({
        "ok": True, "message": {
            "id": message.pk, "text": message.text, "mine": True,
            "created_at": timezone.localtime(message.created_at).strftime("%H:%M"),
        },
    })


@login_required
def poll_messages(request, username):
    other = get_object_or_404(User, username=username, is_active=True)
    if other.pk == request.user.pk:
        return JsonResponse({"messages": []})
    try:
        after_id = max(0, int(request.GET.get("after", 0)))
    except (TypeError, ValueError):
        after_id = 0
    new_messages = list(
        Message.objects.filter(id__gt=after_id)
        .filter(Q(sender=request.user, recipient=other) | Q(sender=other, recipient=request.user))
        .select_related("sender").order_by("created_at", "id")[:100]
    )
    incoming_ids = [m.pk for m in new_messages if m.sender_id == other.pk and not m.is_read]
    if incoming_ids:
        Message.objects.filter(pk__in=incoming_ids).update(is_read=True, read_at=timezone.now())
    return JsonResponse({"messages": [
        {
            "id": m.id, "text": m.text, "mine": m.sender_id == request.user.id,
            "created_at": timezone.localtime(m.created_at).strftime("%H:%M"),
        } for m in new_messages
    ]})
