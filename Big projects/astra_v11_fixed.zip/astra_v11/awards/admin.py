from django.contrib import admin
from .models import CompetitionAward, DailyChampion, MonthlyChampion, ScoreEntry


@admin.register(ScoreEntry)
class ScoreEntryAdmin(admin.ModelAdmin):
    list_display = ("user", "kind", "points", "actor", "created_at")
    list_filter = ("kind", "created_at")
    search_fields = ("user__username", "actor__username", "source_key")
    readonly_fields = ("user", "actor", "kind", "points", "source_key", "created_at")
    date_hierarchy = "created_at"
    list_select_related = ("user", "actor")
    def has_add_permission(self, request): return False


@admin.register(DailyChampion)
class DailyChampionAdmin(admin.ModelAdmin):
    list_display = ("award_date", "user", "score_at_close", "points_awarded")
    list_filter = ("award_date",)
    search_fields = ("user__username",)
    readonly_fields = ("award_date", "user", "score_at_close", "points_awarded", "created_at")
    def has_add_permission(self, request): return False


@admin.register(MonthlyChampion)
class MonthlyChampionAdmin(admin.ModelAdmin):
    list_display = ("year", "month", "user", "points", "created_at")
    list_filter = ("year", "month")
    search_fields = ("user__username",)
    readonly_fields = ("year", "month", "user", "points", "created_at")
    def has_add_permission(self, request): return False


@admin.register(CompetitionAward)
class CompetitionAwardAdmin(admin.ModelAdmin):
    list_display = ("title", "period_type", "period_start", "user", "score_at_close", "claimed_at")
    list_filter = ("period_type", "claimed_at", "period_start")
    search_fields = ("user__username", "title")
    readonly_fields = ("period_type", "period_start", "period_end", "user", "score_at_close", "awarded_at", "claimed_at")
    list_select_related = ("user",)
    date_hierarchy = "period_end"
    def has_add_permission(self, request): return False
    def has_delete_permission(self, request, obj=None): return False
