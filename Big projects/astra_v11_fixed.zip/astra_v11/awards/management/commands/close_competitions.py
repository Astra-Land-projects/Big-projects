from django.core.management.base import BaseCommand
from awards.services import finalize_competitions
from rank.services import finalize_closed_rank_prizes


class Command(BaseCommand):
    help = "Finalize completed Astra Awards periods and create winner awards."
    def handle(self, *args, **options):
        result = finalize_competitions()
        rank_prizes = finalize_closed_rank_prizes()
        self.stdout.write(self.style.SUCCESS(
            f"Awards updated: {result['days']} daily log(s), {result['months']} monthly log(s), {result['awards']} new period award(s); {rank_prizes} Rank seasonal/yearly prize(s)."
        ))
