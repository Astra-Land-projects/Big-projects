# Generated for Astra v9.
import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True
    dependencies = [migrations.swappable_dependency(settings.AUTH_USER_MODEL)]

    operations = [
        migrations.CreateModel(
            name="ScoreEntry",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("kind", models.CharField(choices=[("post", "Published post"), ("like", "Received like"), ("comment", "Received comment")], max_length=12)),
                ("points", models.PositiveSmallIntegerField()),
                ("source_key", models.CharField(max_length=120, unique=True)),
                ("created_at", models.DateTimeField(auto_now_add=True, db_index=True)),
                ("actor", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="astra_score_actions", to=settings.AUTH_USER_MODEL)),
                ("user", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="astra_score_entries", to=settings.AUTH_USER_MODEL)),
            ],
            options={"ordering": ["-created_at"]},
        ),
        migrations.CreateModel(
            name="DailyChampion",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("award_date", models.DateField(db_index=True)),
                ("points_awarded", models.PositiveSmallIntegerField(default=5)),
                ("score_at_close", models.PositiveIntegerField(default=0)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("user", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="astra_daily_awards", to=settings.AUTH_USER_MODEL)),
            ],
            options={"ordering": ["-award_date", "user__username"]},
        ),
        migrations.CreateModel(
            name="MonthlyChampion",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("year", models.PositiveSmallIntegerField()),
                ("month", models.PositiveSmallIntegerField()),
                ("points", models.PositiveIntegerField(default=0)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("user", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="astra_monthly_awards", to=settings.AUTH_USER_MODEL)),
            ],
            options={"ordering": ["-year", "-month", "user__username"]},
        ),
        migrations.AddConstraint(
            model_name="dailychampion",
            constraint=models.UniqueConstraint(fields=("award_date", "user"), name="unique_daily_champion_user"),
        ),
        migrations.AddConstraint(
            model_name="monthlychampion",
            constraint=models.UniqueConstraint(fields=("year", "month", "user"), name="unique_monthly_champion_user"),
        ),
        migrations.AddIndex(
            model_name="scoreentry",
            index=models.Index(fields=["user", "created_at"], name="awards_scor_user_id_b43dee_idx"),
        ),
        migrations.AddIndex(
            model_name="scoreentry",
            index=models.Index(fields=["kind", "created_at"], name="awards_scor_kind_707073_idx"),
        ),
    ]
