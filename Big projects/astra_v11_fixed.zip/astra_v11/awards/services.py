from collections import defaultdict
from datetime import date, datetime, time, timedelta
from django.db import transaction
from django.db.models import Sum
from django.utils import timezone
from .models import CompetitionAward, DailyChampion, MonthlyChampion, ScoreEntry

POST_POINTS = 10
LIKE_POINTS = 2
COMMENT_POINTS = 3
DAILY_CHAMPION_POINTS = 0  # Awards winners receive a trophy, not bonus points.
DAILY_POST_LIMIT = 3


def _day_bounds(day):
    tz = timezone.get_current_timezone()
    return timezone.make_aware(datetime.combine(day, time.min), tz), timezone.make_aware(datetime.combine(day + timedelta(days=1), time.min), tz)


def record_post_score(post):
    today = timezone.localdate()
    start, end = _day_bounds(today)
    existing = ScoreEntry.objects.filter(user=post.author, kind=ScoreEntry.Kind.POST, created_at__gte=start, created_at__lt=end).count()
    if existing >= DAILY_POST_LIMIT: return False
    ScoreEntry.objects.get_or_create(source_key=f"post:{post.pk}", defaults={"user": post.author, "actor": post.author, "kind": ScoreEntry.Kind.POST, "points": POST_POINTS})
    return True


def record_like_score(like):
    if like.user_id == like.post.author_id: return
    entry, created = ScoreEntry.objects.get_or_create(source_key=f"like:{like.post_id}:{like.user_id}", defaults={"user": like.post.author, "actor": like.user, "kind": ScoreEntry.Kind.LIKE, "points": LIKE_POINTS})
    if not created and entry.points == 0:
        entry.points = LIKE_POINTS
        entry.created_at = timezone.now()
        entry.save(update_fields=["points", "created_at"])


def remove_like_score(like):
    ScoreEntry.objects.filter(source_key=f"like:{like.post_id}:{like.user_id}").update(points=0)


def record_comment_score(comment):
    if comment.user_id == comment.post.author_id: return
    ScoreEntry.objects.get_or_create(source_key=f"comment:{comment.post_id}:{comment.user_id}", defaults={"user": comment.post.author, "actor": comment.user, "kind": ScoreEntry.Kind.COMMENT, "points": COMMENT_POINTS})


def record_rank_submission_score(submission):
    """Credit an approved Rank submission to Awards exactly once; never double-count it."""
    if submission.status != "approved": return
    entry, created = ScoreEntry.objects.get_or_create(
        source_key=f"rank:{submission.pk}",
        defaults={"user": submission.user, "actor": submission.user, "kind": ScoreEntry.Kind.RANK, "points": submission.points},
    )
    if not created and entry.points != submission.points:
        entry.points = submission.points
        entry.created_at = timezone.now()
        entry.save(update_fields=["points", "created_at"])


def _user_scores_for_period(start, end):
    return {row["user_id"]: row["total"] or 0 for row in ScoreEntry.objects.filter(created_at__gte=start, created_at__lt=end, points__gt=0).values("user_id").annotate(total=Sum("points"))}


def _period_start(day, period):
    if period == "daily": return day
    if period == "weekly": return day - timedelta(days=day.weekday())
    if period == "monthly": return day.replace(day=1)
    if period == "quarterly": return date(day.year, ((day.month - 1)//3)*3 + 1, 1)
    if period == "yearly": return date(day.year, 1, 1)
    raise ValueError("Unsupported Awards period")


def _period_end(start, period):
    if period == "daily": return start + timedelta(days=1)
    if period == "weekly": return start + timedelta(days=7)
    if period == "monthly": return date(start.year + (start.month == 12), 1 if start.month == 12 else start.month + 1, 1)
    if period == "quarterly": return date(start.year + (start.month == 10), 1 if start.month == 10 else start.month + 3, 1)
    if period == "yearly": return date(start.year + 1, 1, 1)
    raise ValueError("Unsupported Awards period")


def _aware(date_value):
    return timezone.make_aware(datetime.combine(date_value, time.min), timezone.get_current_timezone())


def _period_label(period):
    return {"daily": "Daily Champion", "weekly": "Weekly Champion", "monthly": "Monthly Champion", "quarterly": "Quarterly Champion", "yearly": "Annual Champion"}[period]


@transaction.atomic
def finalize_closed_period_awards(today=None):
    """Create durable award records for completed daily/weekly/monthly/quarterly/yearly periods."""
    today = today or timezone.localdate()
    scored_dates = ScoreEntry.objects.filter(points__gt=0, created_at__date__lt=today).dates("created_at", "day", order="ASC")
    created = 0
    for period in ("daily", "weekly", "monthly", "quarterly", "yearly"):
        starts = sorted({_period_start(day, period) for day in scored_dates})
        for start_date in starts:
            end_date = _period_end(start_date, period)
            if end_date > today:
                continue
            scores = _user_scores_for_period(_aware(start_date), _aware(end_date))
            if not scores: continue
            highest = max(scores.values())
            for user_id, score in scores.items():
                if score != highest: continue
                _, was_created = CompetitionAward.objects.get_or_create(
                    period_type=period, period_start=start_date, user_id=user_id,
                    defaults={"period_end": end_date - timedelta(days=1), "title": f"Astra {_period_label(period)}", "icon": "🏆" if period in ("quarterly", "yearly") else "🏅", "score_at_close": score},
                )
                created += int(was_created)
    return created


@transaction.atomic
def finalize_closed_days(today=None):
    """Preserve legacy daily champion history without granting winner bonus points."""
    today = today or timezone.localdate()
    old_days = ScoreEntry.objects.filter(created_at__date__lt=today, points__gt=0).dates("created_at", "day", order="ASC")
    closed = 0
    for day in old_days:
        if DailyChampion.objects.filter(award_date=day).exists(): continue
        start, end = _day_bounds(day)
        scores = _user_scores_for_period(start, end)
        if not scores: continue
        highest = max(scores.values())
        for user_id, score in scores.items():
            if score == highest:
                DailyChampion.objects.get_or_create(award_date=day, user_id=user_id, defaults={"points_awarded": 0, "score_at_close": score})
        closed += 1
    return closed


@transaction.atomic
def finalize_closed_months(today=None):
    """Keep the legacy monthly champion log, based on activity points only."""
    today = today or timezone.localdate()
    first = today.replace(day=1)
    cutoff = _aware(first)
    month_dates = ScoreEntry.objects.filter(created_at__lt=cutoff, points__gt=0).dates("created_at", "month", order="ASC")
    created = 0
    for month_date in month_dates:
        year, month = month_date.year, month_date.month
        if MonthlyChampion.objects.filter(year=year, month=month).exists(): continue
        start_date = date(year, month, 1)
        end_date = _period_end(start_date, "monthly")
        scores = _user_scores_for_period(_aware(start_date), _aware(end_date))
        if not scores: continue
        highest = max(scores.values())
        for user_id, score in scores.items():
            if score == highest:
                MonthlyChampion.objects.get_or_create(year=year, month=month, user_id=user_id, defaults={"points": score})
        created += 1
    return created


def finalize_competitions(today=None):
    today = today or timezone.localdate()
    return {"days": finalize_closed_days(today=today), "months": finalize_closed_months(today=today), "awards": finalize_closed_period_awards(today=today)}


def build_rows(scores, limit=20):
    from django.contrib.auth import get_user_model
    User = get_user_model()
    ordered = sorted(scores.items(), key=lambda item: (-item[1], item[0]))[:limit]
    users = User.objects.filter(pk__in=[uid for uid, _ in ordered]).select_related("profile")
    by_id = {u.pk: u for u in users}
    return [{"position": i, "user": by_id[uid], "points": pts} for i, (uid, pts) in enumerate(ordered, 1) if uid in by_id]


def month_scores(year, month):
    start_date = date(year, month, 1)
    end_date = _period_end(start_date, "monthly")
    return _user_scores_for_period(_aware(start_date), _aware(end_date))


def current_period_scores(today, period):
    start_date = _period_start(today, period)
    end_date = _period_end(start_date, period)
    return _user_scores_for_period(_aware(start_date), _aware(end_date)), start_date, end_date
