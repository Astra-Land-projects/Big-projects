from django.urls import path
from . import views

app_name = "awards"

urlpatterns = [
    path("", views.leaderboard, name="leaderboard"),
    path("claim/<int:award_id>/", views.claim_award, name="claim"),
]
