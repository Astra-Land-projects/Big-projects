import calendar
from datetime import timedelta
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST
from .models import CompetitionAward, DailyChampion, MonthlyChampion
from .services import build_rows, current_period_scores, finalize_competitions

PERIODS = {"daily": "Daily", "weekly": "Weekly", "monthly": "Monthly", "quarterly": "Quarterly", "yearly": "Yearly"}


def leaderboard(request):
    today = timezone.localdate()
    finalize_competitions(today=today)
    period = request.GET.get("period", "monthly")
    if period not in PERIODS: period = "monthly"
    scores, start_date, end_date = current_period_scores(today, period)
    rows = build_rows(scores)
    labels = {
        "daily": today.strftime("%B %d, %Y"),
        "weekly": f"{start_date:%b %d} – {end_date - timedelta(days=1):%b %d, %Y}",
        "monthly": f"{calendar.month_name[today.month]} {today.year}",
        "quarterly": f"Q{((today.month - 1)//3) + 1} {today.year}",
        "yearly": str(today.year),
    }
    last_month = today.replace(day=1) - timedelta(days=1)
    previous_champions = list(MonthlyChampion.objects.filter(year=last_month.year, month=last_month.month).select_related("user", "user__profile"))
    latest_daily_champions = DailyChampion.objects.select_related("user", "user__profile").order_by("-award_date")[:8]
    ceremony_key = f"astra_awards_ceremony_{last_month.year}_{last_month.month}"
    show_ceremony_celebration = bool(previous_champions) and not request.session.get(ceremony_key, False)
    if show_ceremony_celebration: request.session[ceremony_key] = True
    show_claim_celebration = bool(request.session.pop("astra_claimed_award_id", None))
    claimable_awards = CompetitionAward.objects.filter(user=request.user, claimed_at__isnull=True) if request.user.is_authenticated else CompetitionAward.objects.none()
    claimed_awards = CompetitionAward.objects.filter(user=request.user, claimed_at__isnull=False) if request.user.is_authenticated else CompetitionAward.objects.none()
    return render(request, "awards/leaderboard.html", {
        "month_rows": rows, "daily_rows": build_rows(scores, limit=10) if period == "daily" else build_rows(current_period_scores(today, "daily")[0], limit=10),
        "month_label": labels[period], "previous_month_label": f"{calendar.month_name[last_month.month]} {last_month.year}",
        "previous_champions": previous_champions, "latest_daily_champions": latest_daily_champions,
        "score_rules": [("Published post", 10, "Up to 3 posts per person each day"), ("Received like", 2, "Each unique like from another member"), ("Received comment", 3, "First comment from each member on a post"), ("Approved Rank achievement", "Varies", "Certificate, medal and other approved evidence points")],
        "has_month_activity": bool(rows), "show_ceremony_celebration": show_ceremony_celebration,
        "period": period, "periods": PERIODS, "claimable_awards": claimable_awards, "claimed_awards": claimed_awards,
        "show_claim_celebration": show_claim_celebration,
    })


@login_required
@require_POST
@transaction.atomic
def claim_award(request, award_id):
    award = get_object_or_404(CompetitionAward.objects.select_for_update(), pk=award_id, user=request.user)
    if award.claimed_at is None:
        award.claimed_at = timezone.now()
        award.save(update_fields=["claimed_at"])
        request.session["astra_claimed_award_id"] = award.pk
        messages.success(request, "Your Astra award has been revealed and saved to your profile.")
    else:
        messages.info(request, "This award is already in your profile.")
    return redirect("awards:leaderboard")
