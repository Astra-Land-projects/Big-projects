from django.contrib import admin
from django.http import HttpResponse
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.sites.requests import RequestSite
from django.template.response import TemplateResponse
from django.views.generic import RedirectView

from accour.views import social_cancelled

from .sitemaps import ArticleSitemap, StaticViewSitemap

admin.site.site_header = "ASTRA | Control Center"
admin.site.site_title = "ASTRA Administration"
admin.site.index_title = "Manage the Astra ecosystem"
admin.site.index_template = "admin/astra_index.html"

sitemaps = {
    "static": StaticViewSitemap,
    "articles": ArticleSitemap,
}


def sitemap_xml(request):
    """
    /sitemap.xml built from the address the visitor used (for example https://arya8.pythonanywhere.com),
    so the links are always correct and never fall back to the Sites framework default "example.com".
    """
    site = RequestSite(request)
    urls = []
    for sitemap_class in sitemaps.values():
        urls.extend(sitemap_class().get_urls(page=1, site=site, protocol=request.scheme))
    response = TemplateResponse(request, "sitemap.xml", {"urlset": urls}, content_type="application/xml")
    response["X-Robots-Tag"] = "noindex, noodp, noarchive"
    return response


PRIVATE_PATHS = (
    "/admin/",
    "/accounts/",
    "/login/",
    "/logout/",
    "/profile/",
    "/astragram/messages/",
    "/astragram/post/",
    "/astra-ai/chat/",
    "/rank/",
)


def robots_txt(request):
    # Search visibility and model-training preferences are independent controls.
    lines = ["User-agent: *", "Allow: /"]
    lines += [f"Disallow: {path}" for path in PRIVATE_PATHS]
    lines += ["", "User-agent: OAI-SearchBot"]
    lines += ["Allow: /" if settings.ALLOW_OAI_SEARCHBOT else "Disallow: /"]
    lines += [f"Disallow: {path}" for path in PRIVATE_PATHS]
    lines += ["", "User-agent: GPTBot"]
    lines += ["Allow: /" if settings.ALLOW_GPTBOT else "Disallow: /"]
    lines += [f"Disallow: {path}" for path in PRIVATE_PATHS]
    lines += ["", f"Sitemap: {request.scheme}://{request.get_host()}/sitemap.xml", ""]
    return HttpResponse("\n".join(lines), content_type="text/plain")


def llms_txt(request):
    """Optional plain-language map for AI tools; not a search/indexing guarantee."""
    origin = f"{request.scheme}://{request.get_host()}"
    content = f"""# ASTRA

Astra is an AI-focused website with public information about its tools and community.

## Public pages
- Home: {origin}/
- About: {origin}/about-us/
- Astra AI: {origin}/astra-ai/
- News: {origin}/news/
- Music: {origin}/music/
- Gallery: {origin}/gallery/
- Events and celebrations: {origin}/events/
- Awards: {origin}/awards/
- Mini Games: {origin}/mini-game/
- Terms: {origin}/terms/
- Privacy: {origin}/privacy/

## Discovery
The public sitemap is available at {origin}/sitemap.xml. Private account, administration, profile, direct-message, and submission routes are not public documentation.
"""
    return HttpResponse(content, content_type="text/plain; charset=utf-8")


urlpatterns = [
    path('admin/', admin.site.urls),

    path('sitemap.xml', sitemap_xml, name='sitemap'),
    path('robots.txt', robots_txt, name='robots_txt'),
    path('llms.txt', llms_txt, name='llms_txt'),

    # allauth's own login/sign-up pages are replaced by the Astra login page.
    path('accounts/social/login/cancelled/', social_cancelled, name='social_cancelled'),
    path('accounts/login/', RedirectView.as_view(pattern_name='login', query_string=True)),
    path('accounts/signup/', RedirectView.as_view(pattern_name='login', query_string=True)),
    path('accounts/', include('allauth.urls')),

    path('', include('accour.urls')),
    path('', include('core.urls')),
    path('gallery/', include('gallery.urls')),
    path('music/', include('music.urls')),
    path('news/', include('newsroom.urls')),
    path('astragram/', include('astragram.urls')),
    path('rank/', include('rank.urls')),
    path('events/', include('events.urls')),
    path('awards/', include('awards.urls')),
    path('mini-game/', include('minigames.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
