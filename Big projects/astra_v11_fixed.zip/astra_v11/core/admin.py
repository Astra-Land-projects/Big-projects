from django.contrib import admin

from .models import AboutContent, AstraAIConversation, AstraAIMessage, ContactMessage, HomeSlide


@admin.register(AboutContent)
class AboutContentAdmin(admin.ModelAdmin):
    def has_add_permission(self, request):
        return not AboutContent.objects.exists()

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(HomeSlide)
class HomeSlideAdmin(admin.ModelAdmin):
    list_display = ("title", "media_type", "order", "is_active")
    list_editable = ("order", "is_active")
    list_filter = ("media_type", "is_active")
    radio_fields = {"media_type": admin.HORIZONTAL}
    fieldsets = (
        ("Slide text", {"fields": ("title", "description", "button_text", "button_link")}),
        ("Media", {"description": "Choose Image or Video. Video settings apply only to video slides.", "fields": ("media_type", "image", "video", "video_autoplay", "video_sound")}),
        ("Display", {"fields": ("order", "is_active")}),
    )

    class Media:
        js = ("js/astra-admin-slides.js",)


@admin.register(ContactMessage)
class ContactMessageAdmin(admin.ModelAdmin):
    list_display = ("name", "email", "subject", "source_page", "emailed_ok", "created_at")
    list_filter = ("source_page", "emailed_ok")
    readonly_fields = ("name", "email", "subject", "message", "source_page", "created_at", "emailed_ok")


class AstraAIMessageInline(admin.TabularInline):
    model = AstraAIMessage
    extra = 0
    can_delete = False
    readonly_fields = ("role", "content", "created_at")
    fields = ("role", "content", "created_at")

    def has_add_permission(self, request, obj=None):
        return False


@admin.register(AstraAIConversation)
class AstraAIConversationAdmin(admin.ModelAdmin):
    list_display = ("title", "user", "created_at", "updated_at", "message_count")
    search_fields = ("title", "user__username", "user__email", "messages__content")
    list_filter = ("created_at", "updated_at")
    readonly_fields = ("user", "title", "created_at", "updated_at")
    inlines = (AstraAIMessageInline,)

    @admin.display(description="Messages")
    def message_count(self, obj):
        return obj.messages.count()

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return request.user.is_superuser


@admin.register(AstraAIMessage)
class AstraAIMessageAdmin(admin.ModelAdmin):
    list_display = ("conversation", "role", "short_content", "created_at")
    list_filter = ("role", "created_at")
    search_fields = ("content", "conversation__user__username", "conversation__title")
    readonly_fields = ("conversation", "role", "content", "created_at")

    @admin.display(description="Message")
    def short_content(self, obj):
        return obj.content[:100]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False
