import core.validators
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("core", "0001_initial"),
    ]

    operations = [
        migrations.AddField(
            model_name="homeslide",
            name="media_type",
            field=models.CharField(
                choices=[("image", "Image"), ("video", "Video")],
                default="image",
                help_text="Choose what this slide shows: a picture or a video.",
                max_length=10,
            ),
        ),
        migrations.AddField(
            model_name="homeslide",
            name="video",
            field=models.FileField(
                blank=True,
                help_text="MP4, WebM, OGV or M4V, up to 60 MB. MP4 (H.264) works in every browser.",
                null=True,
                upload_to="home_slides/videos/",
                validators=[core.validators.validate_video_file],
            ),
        ),
        migrations.AddField(
            model_name="homeslide",
            name="video_autoplay",
            field=models.BooleanField(default=True, help_text="Start the video automatically when the slide appears."),
        ),
        migrations.AddField(
            model_name="homeslide",
            name="video_sound",
            field=models.BooleanField(
                default=True,
                help_text="Play with sound. Some browsers block sound until the visitor touches the page; then a sound button is shown.",
            ),
        ),
        migrations.AlterField(
            model_name="homeslide",
            name="image",
            field=models.ImageField(
                blank=True,
                help_text="The slide picture. For a video slide it is shown until the video starts.",
                null=True,
                upload_to="home_slides/",
            ),
        ),
    ]
