from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models

from .validators import validate_video_file


class AboutContent(models.Model):
    """
    Singleton-style model for the About Us page's editable text blocks.
    Only one row is ever used — create/edit it from the Admin panel.
    """

    mission = models.TextField(blank=True, default="")
    vision = models.TextField(blank=True, default="")
    future_plans = models.TextField(blank=True, default="")

    class Meta:
        verbose_name = "About Page Content"
        verbose_name_plural = "About Page Content"

    def __str__(self):
        return "About Us page content"

    @classmethod
    def get_solo(cls):
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj


class HomeSlide(models.Model):
    """Auto-rotating slide shown at the top of the Astra home page. A slide can show an image or a video."""

    class MediaType(models.TextChoices):
        IMAGE = "image", "Image"
        VIDEO = "video", "Video"

    title = models.CharField(max_length=120)
    description = models.CharField(max_length=250, blank=True)
    media_type = models.CharField(
        max_length=10,
        choices=MediaType.choices,
        default=MediaType.IMAGE,
        help_text="Choose what this slide shows: a picture or a video.",
    )
    image = models.ImageField(
        upload_to="home_slides/",
        blank=True,
        null=True,
        help_text="The slide picture. For a video slide it is shown until the video starts.",
    )
    video = models.FileField(
        upload_to="home_slides/videos/",
        blank=True,
        null=True,
        validators=[validate_video_file],
        help_text="MP4, WebM, OGV or M4V, up to 60 MB. MP4 (H.264) works in every browser.",
    )
    video_autoplay = models.BooleanField(default=True, help_text="Start the video automatically when the slide appears.")
    video_sound = models.BooleanField(
        default=True,
        help_text="Play with sound. Some browsers block sound until the visitor touches the page; "
                  "then a sound button is shown.",
    )
    button_text = models.CharField(max_length=50, default="Explore")
    button_link = models.CharField(max_length=200, blank=True, help_text="Internal path or full URL.")
    order = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["order", "id"]

    def __str__(self):
        return self.title

    def clean(self):
        super().clean()
        if self.media_type == self.MediaType.VIDEO and not self.video:
            raise ValidationError({"video": "Upload a video file, or switch this slide to Image."})

    @property
    def has_video(self):
        return self.media_type == self.MediaType.VIDEO and bool(self.video)


class ContactMessage(models.Model):
    """
    Stores every submission from the Support / About Us feedback forms,
    as a record kept in the database in addition to the email that gets
    sent out — so nothing is lost even if the email fails to send.
    """

    name = models.CharField(max_length=120, blank=True)
    email = models.EmailField(blank=True)
    subject = models.CharField(max_length=150, blank=True)
    message = models.TextField()
    source_page = models.CharField(max_length=50, default="support")
    created_at = models.DateTimeField(auto_now_add=True)
    emailed_ok = models.BooleanField(default=False)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.name or 'Anonymous'} — {self.subject or self.source_page}"


class AstraAIConversation(models.Model):
    """Saved conversation history for a signed-in Astra member."""
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="astra_ai_conversations"
    )
    title = models.CharField(max_length=120, default="New conversation")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True, db_index=True)

    class Meta:
        ordering = ["-updated_at"]

    def __str__(self):
        return f"{self.user} — {self.title}"


class AstraAIMessage(models.Model):
    class Role(models.TextChoices):
        USER = "user", "User"
        ASSISTANT = "assistant", "Astra AI"

    conversation = models.ForeignKey(
        AstraAIConversation, on_delete=models.CASCADE, related_name="messages"
    )
    role = models.CharField(max_length=12, choices=Role.choices)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ["created_at", "id"]
        indexes = [models.Index(fields=["conversation", "created_at"], name="core_ai_conv_created_idx")]

    def __str__(self):
        return f"{self.get_role_display()} · conversation {self.conversation_id}"
