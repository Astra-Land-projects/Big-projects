from django.urls import path

from . import views

urlpatterns = [
    path("astra-ai/", views.astra_ai, name="astra_ai"),
    path("astra-ai/chat/", views.astra_ai_chat, name="astra_ai_chat"),
    path("help-center/", views.help_center, name="help_center"),
    path("astra-clock/", views.astra_clock, name="astra_clock"),
    path("about-us/", views.about_us, name="about_us"),
    path("support/", views.support, name="support"),
]
