import json
import random
import re
import urllib.error
import urllib.request

from django.conf import settings
from django.contrib import messages
from django.core.mail import send_mail
from django.http import JsonResponse
from django.shortcuts import redirect, render
from django.views.decorators.http import require_POST

from .ai_knowledge import EXTRA_FOLLOW_UPS, EXTRA_RULES
from .models import AboutContent, AstraAIConversation, AstraAIMessage, ContactMessage

# ---------------------------------------------------------------------
# Astra AI — keyword-based assistant (same zero-cost pattern used on
# Astra Education / Astra Shop: specific trigger words -> a fixed reply).
# ---------------------------------------------------------------------

RULES = [
    ("identity", ("who are you", "what are you", "your name", "introduce yourself"),
     "I'm Astra AI, the assistant inside the Astra ecosystem. I can guide you around the platform, explain its features, help with account questions, and share useful ideas about learning, programming, and technology. I use a curated set of conversation rules on this version of Astra, so I will be clear when a question needs information I do not have."),
    ("greeting", ("hello", "hi", "hey", "good morning", "good afternoon", "good evening"),
     "Hello and welcome to Astra! It is good to have you here. You can ask me about Astragram, Astra AI, Events, Awards, your profile, or any of the other sections. What would you like to explore today?"),
    ("thanks", ("thank you", "thanks", "appreciate it", "thx"),
     "You're very welcome! I'm glad I could help. You can keep asking questions about Astra or tell me which part you are trying to use, and I will guide you through it step by step."),
    ("goodbye", ("goodbye", "bye", "see you", "talk later", "have a good day"),
     "See you next time! Thanks for visiting Astra. Your profile, posts, and community activity will be here when you return. Have a great day!"),
    ("login", ("login", "log in", "sign in", "sign up", "signup", "register", "create account", "new account"),
     "You can use the Login button in the top bar to open the Astra account page. Choose Login for an existing account or Sign Up to create a new one. New registrations are activated automatically and you are signed in as soon as the account is created. You can use your username or email address to sign in. Never share your password with anyone."),
    ("password", ("forgot password", "reset password", "change password", "password help", "cannot log in", "can't log in"),
     "First, check that your username or email address and password are typed correctly. Astra's current sign-in page supports username or email. If you are already signed in, use the account settings available through Django's account tools to update your password; if you are locked out, contact the Astra site administrator for a secure reset. Do not send your password in a support message."),
    ("profile", ("profile", "avatar", "profile picture", "profile photo", "bio", "banner"),
     "Open My Profile from the site menu after signing in. You can update your profile picture, banner, and short bio there. Your Astragram post header uses the same profile picture, so changing your avatar on the profile page updates the photo shown next to your posts too."),
    ("astragram", ("astragram", "social feed", "community feed", "publish a post", "make a post", "new post"),
     "Astragram is the community feed in Astra. Signed-in members can share a caption, add an image, like posts, and write comments. Your profile photo appears beside your name on each post. Keep posts respectful and avoid sharing private information about yourself or other people."),
    ("likes-comments", ("like", "likes", "comment", "comments", "reply to a post"),
     "You can like a post with its heart button and add a comment in the field underneath it. A member can like a post once at a time, and removing a like removes the related award points. Points are earned by the post owner when another member interacts with the post; your own likes and comments on your own posts do not count."),
    ("events", ("events", "event page", "celebration", "celebrate", "festival", "festivals"),
     "Events is Astra's celebration space. The site team can create an event in Django Admin by adding a title, description, celebration message, start and end times, theme, and accent color. Once it is published, it appears on the Events page. When its scheduled time arrives, it becomes live automatically and can show the celebration animation."),
    ("christmas", ("christmas", "xmas", "new year celebration"),
     "Christmas can be created as an Astra Event from Django Admin. Add the event dates, choose the Winter Lights theme, write a greeting such as 'Merry Christmas!', and publish it. The event page will show it during its scheduled period with the winter-inspired celebration style."),
    ("halloween", ("halloween", "trick or treat"),
     "Halloween can have its own event card and celebration. Add it in Django Admin, choose the Midnight Celebration theme, set the start and end times, and publish it. Astra will automatically mark it as live when the scheduled period begins."),
    ("yalda", ("yalda", "shab-e yalda", "yalda night"),
     "Shab-e Yalda can be celebrated in Astra Events. Create an event with the title 'Shab-e Yalda', add your English greeting and description, set the date and time, select a warm gold or custom theme, and publish it. When the date arrives, visitors will see the live celebration."),
    ("nowruz", ("nowruz", "norooz", "persian new year"),
     "Nowruz can be added just like any other Astra Event. Choose the Spring Festival theme, set the exact start and end times, and add an English message such as 'Happy Nowruz!'. The Events page reads the schedule automatically, so you do not need to edit the page when the day arrives."),
    ("points", ("points", "scoring", "how do i earn", "earn points", "leaderboard", "daily winner", "daily champion"),
     "The Astra Awards scoring rules are simple: a qualifying post earns 10 points, up to three posts per day; each unique like from another member earns the post owner 2 points; and each comment from another member earns the post owner 3 points. The daily leader receives 5 bonus points when that day closes. Self-interactions do not earn points, and tied daily leaders each receive the daily bonus."),
    ("awards", ("awards", "award", "monthly winner", "monthly champion", "trophy", "ballon d'or", "golden ball"),
     "Astra Awards is the monthly community competition. Members collect points through Astragram activity, and the monthly leaderboard displays the current standings. When a month is complete, Astra records the highest-scoring member as the monthly champion. The award design uses Astra's gold visual identity."),
    ("rank", ("astra rank", "rank page", "achievement proof", "submit an achievement", "certificate points"),
     "Astra Rank and Astra Awards have different purposes. Astra Rank is for achievements submitted with proof for review. Astra Awards is the monthly community competition based on Astragram posts and interactions. You can find both from the site menu."),
    ("astra-ai", ("astra ai", "ai assistant", "artificial intelligence", "how smart are you", "what can you do"),
     "I can answer common questions about the Astra ecosystem, explain where features are, and offer general guidance. This Astra version uses an expanded keyword-and-response knowledge set rather than a live generative AI model, so I may not understand every open-ended question. For coding or research questions, use a dedicated AI service and verify important information."),
    ("programming", ("programming", "coding", "write code", "python", "javascript", "html", "css", "api"),
     "Programming is a great way to build practical projects. A useful path is to learn Python fundamentals, practise with small programs, understand Git and HTTP APIs, then build web applications with Django or FastAPI and a database. Start with one small feature, test it, and improve it gradually. I can help explain Astra's own code structure, but I cannot execute code from this chat."),
    ("django", ("django", "django admin", "admin panel", "administrator", "manage events"),
     "The Django Admin is the management area for Astra. Open /admin/ and sign in with a staff or superuser account. The Events section lets administrators create and schedule celebrations. Astra Awards contains read-only point records and daily or monthly champion history, so the scoring history can be reviewed without editing scores manually."),
    ("news", ("news", "articles", "technology news", "latest technology"),
     "Astra News is the platform's article area for technology and AI topics. Open it from the site menu to browse published articles. If you are looking for a particular subject, use the page's search feature when it is available."),
    ("music", ("music", "song", "songs", "audio", "player"),
     "Astra Music is the listening section of the ecosystem. Open it from the menu to browse available tracks and use the player controls on the page. If a track does not play, check the device volume and try another available track."),
    ("gallery", ("gallery", "photos", "pictures", "images"),
     "Astra Gallery is the visual collection area. Open Gallery from the menu to explore the images that have been published. The gallery is separate from Astragram: Gallery is for browsing the collection, while Astragram is for community posts and discussion."),
    ("clock", ("clock", "time zones", "world time", "calendar", "date"),
     "Astra Clock is the time and calendar section. Open it from the menu to explore the available clocks and date information. Time-zone results depend on the city or region selected on the Clock page."),
    ("education", ("education", "courses", "learn", "study"),
     "Astra Education is planned as a learning area. While it is marked Coming Soon on the current site, you can already use the existing Astra AI, News, and community features to explore technology topics and share learning progress."),
    ("about", ("about astra", "about us", "mission", "vision"),
     "Astra is an AI-focused digital ecosystem built around useful tools and community features. The site brings together an assistant, social feed, news, music, gallery, clock, and member features. Visit About Us from the menu to read the published mission and vision."),
    ("support", ("support", "contact", "help", "report a problem", "bug"),
     "For a problem that needs the site team, open Support or Contact Us from the footer. Include the page name, what you were trying to do, and the exact error message if one appeared. Do not include your password, login codes, or private account details."),
    ("security", ("security", "privacy", "safe", "personal information", "private information"),
     "Protect your Astra account by using a unique password and signing out on devices you do not control. Share only information you are comfortable making visible to other members. Never post passwords, login codes, addresses, or sensitive documents in Astragram comments or public posts."),
]

DEFAULT_REPLY = (
    "I am not sure I understood that yet. I can help with Astra login and profiles, Astragram posts and messages, "
    "Events and celebrations, Awards and points, Astra Rank, News with Articles and Projects, Music, Gallery, Mini Games, Clock, or Support. "
    "I also know a lot about programming, AI, robotics and careers. Try asking one clear question, for example: how do I add a game?"
)

FOLLOW_UP_DETAILS = {
    "events": "For each event, fill in the title, description, celebration message, start and end date/time, theme, accent color, and publication switch. Keep the end time later than the start time. Save it as a draft while preparing it, then publish it when ready.",
    "awards": "The Awards page shows the live score for the current month, today's standings, the previous month's champion, and recent daily champions. Daily bonuses are finalized after a day ends. A completed month is stored as a permanent champion record.",
    "profile": "The avatar and banner are uploaded from My Profile. Save your changes after choosing an image. The same avatar field is used in the Astragram post header, so you do not need to upload the same photo twice.",
    "login": "For a new account, open Sign Up, choose a username, enter an email if you want to use it at sign-in, and choose a strong password. Astra activates public registrations automatically and signs you in after account creation.",
    "points": "Points belong to the author of the post that receives the interaction. Removing a like removes its 2 points. A post can earn points once, and only the first three posts per member each day are eligible for the 10-point post reward.",
}


FOLLOW_UP_DETAILS = {**EXTRA_FOLLOW_UPS, **FOLLOW_UP_DETAILS}
FOLLOW_UP_PHRASES = ("tell me more", "more details", "explain more", "continue", "go on", "elaborate", "say more", "explain further", "what else")


def _compile_matchers():
    """One compiled pattern per keyword: (keyword length, is_new_rule, topic, pattern, reply)."""
    matchers = []
    for is_extra, rules in ((False, RULES), (True, EXTRA_RULES)):
        for topic, keywords, reply in rules:
            for keyword in keywords:
                pattern = re.compile(r"(?<!\w)" + re.escape(keyword) + r"(?!\w)")
                matchers.append((len(keyword), is_extra, topic, pattern, reply))
    return matchers


_MATCHERS = _compile_matchers()


def _pick_reply(reply):
    return random.choice(reply) if isinstance(reply, (tuple, list)) else reply


def _rule_based_reply(message: str, previous_topic: str = "") -> tuple[str, str]:
    text = re.sub(r"\s+", " ", message.strip().lower().replace("\u2019", "'"))
    if any(phrase in text for phrase in FOLLOW_UP_PHRASES):
        detail = FOLLOW_UP_DETAILS.get(previous_topic)
        if detail:
            return detail, previous_topic

    # The most specific (longest) matching keyword wins; on a tie the newer rule wins.
    best = None
    for length, is_extra, topic, pattern, reply in _MATCHERS:
        if pattern.search(text) and (best is None or (length, is_extra) > best[0]):
            best = ((length, is_extra), topic, reply)
    if best:
        return _pick_reply(best[2]), best[1]
    return DEFAULT_REPLY, ""


def _call_configured_ai(history):
    """Call an optional OpenAI-compatible chat endpoint; returns None if not configured/available."""
    api_key = getattr(settings, "ASTRA_AI_API_KEY", "")
    if not api_key:
        return None

    system_prompt = (
        "You are Astra AI, a helpful assistant on the Astra platform. Be clear, accurate, "
        "respectful, and age-appropriate. Do not claim to access site accounts or files. "
        "For questions about current events or changing facts, say when live browsing is not configured. "
        "Keep private user data private and never ask for passwords or verification codes."
    )
    payload = {
        "model": getattr(settings, "ASTRA_AI_MODEL", "gpt-4o-mini"),
        "messages": [{"role": "system", "content": system_prompt}] + history[-16:],
        "temperature": 0.6,
        "max_tokens": 900,
    }
    base_url = getattr(settings, "ASTRA_AI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
    request = urllib.request.Request(
        base_url + "/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=getattr(settings, "ASTRA_AI_TIMEOUT", 25)) as response:
            result = json.loads(response.read().decode("utf-8"))
        answer = result["choices"][0]["message"]["content"]
        if isinstance(answer, list):
            answer = "\n".join(part.get("text", "") for part in answer if isinstance(part, dict))
        answer = str(answer).strip()
        return answer[:12000] or None
    except (urllib.error.URLError, TimeoutError, ValueError, KeyError, IndexError, TypeError):
        return None


def astra_ai(request):
    conversations = []
    active_conversation = None
    ai_messages = []
    if request.user.is_authenticated:
        conversations = AstraAIConversation.objects.filter(user=request.user)[:30]
        raw_id = request.GET.get("conversation")
        if raw_id and raw_id.isdigit():
            active_conversation = AstraAIConversation.objects.filter(
                pk=int(raw_id), user=request.user
            ).first()
            if active_conversation:
                ai_messages = active_conversation.messages.all()[:200]
    return render(request, "core/astra_ai.html", {
        "conversations": conversations,
        "active_conversation": active_conversation,
        "ai_messages": ai_messages,
        "ai_provider_configured": getattr(settings, "ASTRA_AI_PROVIDER_CONFIGURED", False),
    })


@require_POST
def astra_ai_chat(request):
    """Chat endpoint: persists member history and uses a configured AI provider when available."""
    try:
        data = json.loads(request.body.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        return JsonResponse({"error": "invalid_request"}, status=400)
    if not isinstance(data, dict):
        return JsonResponse({"error": "invalid_request"}, status=400)

    raw_message = data.get("message")
    if not isinstance(raw_message, str):
        return JsonResponse({"error": "empty_message"}, status=400)
    message = raw_message.strip()
    message = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", message)[:2000]
    if not message:
        return JsonResponse({"error": "empty_message"}, status=400)

    conversation = None
    history = []
    if request.user.is_authenticated:
        raw_id = data.get("conversation_id")
        if raw_id:
            try:
                conversation = AstraAIConversation.objects.get(pk=int(raw_id), user=request.user)
            except (TypeError, ValueError, AstraAIConversation.DoesNotExist):
                return JsonResponse({"error": "conversation_not_found"}, status=404)
        else:
            conversation = AstraAIConversation.objects.create(
                user=request.user, title=message[:100] or "New conversation"
            )
        recent_history = list(conversation.messages.order_by("-created_at", "-pk")[:30])
        recent_history.reverse()
        history = [
            {"role": item.role, "content": item.content}
            for item in recent_history
        ]
        AstraAIMessage.objects.create(
            conversation=conversation, role=AstraAIMessage.Role.USER, content=message
        )

    provider_reply = _call_configured_ai(history + [{"role": "user", "content": message}])
    previous_topic = request.session.get("astra_ai_last_topic", "")
    if provider_reply:
        reply, topic, provider = provider_reply, "", "configured"
    else:
        reply, topic = _rule_based_reply(message, previous_topic=previous_topic)
        provider = "knowledge"
        if getattr(settings, "ASTRA_AI_PROVIDER_CONFIGURED", False):
            reply = "I couldn't reach the configured AI service right now. Here is the best matching Astra guide I can provide:\n\n" + reply
    if topic:
        request.session["astra_ai_last_topic"] = topic

    if conversation:
        AstraAIMessage.objects.create(
            conversation=conversation, role=AstraAIMessage.Role.ASSISTANT, content=reply
        )
        if conversation.messages.count() <= 2:
            conversation.title = message[:100]
        conversation.save(update_fields=["title", "updated_at"])

    return JsonResponse({
        "reply": reply,
        "topic": topic,
        "provider": provider,
        "conversation_id": conversation.pk if conversation else None,
    })


# ---------------------------------------------------------------------
# Static-ish pages (unchanged design, now real Django views)
# ---------------------------------------------------------------------


def help_center(request):
    return render(request, "core/help_center.html")


def astra_clock(request):
    return render(request, "core/astra_clock.html")


# ---------------------------------------------------------------------
# About Us / Support — contact & feedback forms that email
# settings.CONTACT_EMAIL, and are also saved to the database as a
# backup in case the email fails to send.
# ---------------------------------------------------------------------


def _handle_contact_submission(request, source_page):
    # Honeypot: a field real users never see or fill in. If it's
    # non-empty, the submission almost certainly came from a bot —
    # silently drop it without saving or emailing anything.
    if request.POST.get("website", "").strip():
        messages.success(request, "Thanks! Your message has been sent.")
        return

    name = request.POST.get("name", "").strip()[:120]
    email = request.POST.get("email", "").strip()[:200]
    subject = request.POST.get("subject", "").strip()[:150]
    body = request.POST.get("message", "").strip()[:5000]

    if not body:
        messages.error(request, "Please write a message before sending.")
        return

    record = ContactMessage.objects.create(
        name=name, email=email, subject=subject, message=body, source_page=source_page
    )

    email_body = (
        f"New message from the Astra {source_page} page.\n\n"
        f"Name: {name or '(not provided)'}\n"
        f"Email: {email or '(not provided)'}\n"
        f"Subject: {subject or '(no subject)'}\n\n"
        f"Message:\n{body}"
    )
    try:
        send_mail(
            subject=f"[Astra {source_page}] {subject or 'New message'}",
            message=email_body,
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[settings.CONTACT_EMAIL],
            fail_silently=False,
        )
        record.emailed_ok = True
        record.save(update_fields=["emailed_ok"])
    except Exception:
        # Message is still saved in the database either way — nothing is lost.
        pass

    messages.success(request, "Thanks! Your message has been sent.")


def support(request):
    if request.method == "POST":
        _handle_contact_submission(request, "support")
        return redirect("support")
    return render(request, "core/support.html")


def about_us(request):
    if request.method == "POST":
        _handle_contact_submission(request, "about_us")
        return redirect("about_us")
    content = AboutContent.get_solo()
    return render(request, "core/about_us.html", {"content": content})
