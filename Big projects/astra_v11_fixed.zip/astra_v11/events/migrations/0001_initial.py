# Generated for Astra v9.
import django.core.validators
from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True
    dependencies = []

    operations = [
        migrations.CreateModel(
            name="Event",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("title", models.CharField(max_length=120)),
                ("slug", models.SlugField(blank=True, max_length=140, unique=True)),
                ("description", models.TextField(blank=True)),
                ("celebration_message", models.CharField(default="The celebration starts here!", help_text="The large message shown when visitors open this event.", max_length=180)),
                ("starts_at", models.DateTimeField(help_text="The event becomes live at this date and time.")),
                ("ends_at", models.DateTimeField(help_text="The event stops being live at this date and time.")),
                ("theme", models.CharField(choices=[("gold", "Astra Gold"), ("winter", "Winter Lights"), ("spring", "Spring Festival"), ("midnight", "Midnight Celebration"), ("custom", "Custom Celebration")], default="gold", max_length=16)),
                ("accent_color", models.CharField(default="#F5C16C", help_text="Six-digit HEX color, such as #F5C16C.", max_length=7, validators=[django.core.validators.RegexValidator(message="Enter a valid six-character HEX color, for example #F5C16C.", regex="^#[0-9A-Fa-f]{6}$")])),
                ("icon", models.CharField(default="✨", help_text="A short celebration emoji.", max_length=12)),
                ("is_published", models.BooleanField(default=False)),
                ("confetti_enabled", models.BooleanField(default=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"verbose_name": "Event", "verbose_name_plural": "Events", "ordering": ["starts_at", "title"]},
        ),
    ]
