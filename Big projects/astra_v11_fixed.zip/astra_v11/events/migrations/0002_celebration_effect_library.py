from django.db import migrations, models


def seed_effects(apps, schema_editor):
    Effect = apps.get_model("events", "CelebrationEffect")
    manager = Effect.objects.using(schema_editor.connection.alias)
    defaults = [
        ("Snowfall", "snowfall", "Soft falling snow particles.", 10),
        ("Santa fly-by", "santa", "A small festive Santa illustration crosses the screen.", 20),
        ("Light bursts", "fireworks", "Gentle decorative light bursts; no real pyrotechnics.", 30),
        ("Golden sparks", "sparks", "Subtle gold spark particles.", 40),
        ("Colorful confetti", "confetti", "Floating colored paper shapes.", 50),
        ("Festive garlands", "garlands", "Decorative lights along the celebration stage.", 60),
        ("Floating stars", "stars", "Slow drifting star shapes.", 70),
        ("Lantern glow", "lanterns", "Warm floating lantern lights.", 80),
    ]
    for name, key, description, order in defaults:
        manager.get_or_create(key=key, defaults={"name": name, "description": description, "order": order, "is_enabled": True})


class Migration(migrations.Migration):
    dependencies = [("events", "0001_initial")]
    operations = [
        migrations.CreateModel(
            name="CelebrationEffect",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=80)),
                ("key", models.SlugField(choices=[("snowfall", "Snowfall"), ("santa", "Santa fly-by"), ("fireworks", "Firework-style light bursts"), ("sparks", "Golden sparks"), ("confetti", "Colorful confetti"), ("garlands", "Festive garlands"), ("stars", "Floating stars"), ("lanterns", "Lantern glow")], max_length=24, unique=True)),
                ("description", models.CharField(blank=True, max_length=180)),
                ("is_enabled", models.BooleanField(default=True)),
                ("order", models.PositiveSmallIntegerField(default=0)),
            ],
            options={"ordering": ["order", "name"], "verbose_name": "Celebration effect", "verbose_name_plural": "Celebration effect library"},
        ),
        migrations.AddField(model_name="event", name="effects", field=models.ManyToManyField(blank=True, help_text="Choose up to three visual effects from the effect library.", related_name="events", to="events.celebrationeffect")),
        migrations.RunPython(seed_effects, migrations.RunPython.noop),
    ]
