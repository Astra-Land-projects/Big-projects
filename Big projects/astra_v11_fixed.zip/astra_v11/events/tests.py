from datetime import timedelta

from django.test import TestCase
from django.utils import timezone

from .models import CelebrationEffect, Event
from .admin import EventAdminForm


class EventModelTests(TestCase):
    def test_slug_is_generated_and_live_window_is_respected(self):
        now = timezone.now()
        event = Event.objects.create(
            title="Shab-e Yalda",
            starts_at=now - timedelta(minutes=1),
            ends_at=now + timedelta(hours=2),
            is_published=True,
        )
        self.assertEqual(event.slug, "shab-e-yalda")
        self.assertTrue(event.is_live)

    def test_unpublished_event_is_not_live(self):
        now = timezone.now()
        event = Event.objects.create(
            title="Private Draft",
            starts_at=now - timedelta(minutes=1),
            ends_at=now + timedelta(hours=2),
            is_published=False,
        )
        self.assertFalse(event.is_live)

    def test_events_page_renders_published_event(self):
        now = timezone.now()
        Event.objects.create(
            title="Happy Nowruz",
            celebration_message="Happy Nowruz!",
            starts_at=now - timedelta(minutes=1),
            ends_at=now + timedelta(hours=2),
            is_published=True,
        )
        response = self.client.get("/events/")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Happy Nowruz")


class EventEffectLibraryTests(TestCase):
    def test_effects_are_selected_from_library_and_capped_at_three(self):
        now = timezone.now()
        effects = [CelebrationEffect.objects.create(name=f"Effect {i}", key=key) for i, key in enumerate(("snowfall", "santa", "fireworks", "sparks"), 1)]
        data = {"title": "Festival", "description": "", "celebration_message": "Welcome", "starts_at": (now + timedelta(days=1)).isoformat(), "ends_at": (now + timedelta(days=2)).isoformat(), "theme": Event.Theme.GOLD, "accent_color": "#F5C16C", "icon": "✨", "is_published": True, "confetti_enabled": True}
        form = EventAdminForm(data, files={}, instance=Event())
        form_valid_before_m2m = form.is_valid()
        self.assertTrue(form_valid_before_m2m, form.errors)
        form.save(commit=False)
        form.instance.save()
        form.save_m2m()
        form.instance.effects.set(effects)
        capped = EventAdminForm({**data, "effects": [str(effect.pk) for effect in effects]}, instance=form.instance)
        # The form-level validator must reject more than three selected effects.
        self.assertFalse(capped.is_valid())
        self.assertIn("effects", capped.errors)
