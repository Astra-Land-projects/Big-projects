from django.contrib import admin

from .models import GalleryPhoto


@admin.register(GalleryPhoto)
class GalleryPhotoAdmin(admin.ModelAdmin):
    list_display = ("title", "location", "order", "is_published", "created_at")
    list_editable = ("order", "is_published")
