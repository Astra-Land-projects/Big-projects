from django.db import models

from core.validators import validate_image_file


class GalleryPhoto(models.Model):
    """A single photo shown on the Astra Gallery page."""

    title = models.CharField(max_length=120, blank=True)
    image = models.ImageField(upload_to="gallery/", validators=[validate_image_file])
    location = models.CharField(max_length=120, blank=True, help_text="e.g. 'Art gallery', 'Northern lights, Iceland'")
    order = models.PositiveIntegerField(default=0)
    is_published = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["order", "-created_at"]

    def __str__(self):
        return self.title or f"Photo #{self.pk}"
