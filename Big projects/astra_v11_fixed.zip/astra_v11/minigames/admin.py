from django.contrib import admin
from django.utils.html import format_html

from .models import Game


@admin.register(Game)
class GameAdmin(admin.ModelAdmin):
    list_display = ("preview", "title", "button_text", "order", "is_published", "created_at")
    list_display_links = ("preview", "title")
    list_editable = ("order", "is_published")
    list_filter = ("is_published",)
    search_fields = ("title", "description")
    prepopulated_fields = {"slug": ("title",)}
    readonly_fields = ("created_at",)
    fieldsets = (
        ("Game", {"fields": ("title", "slug", "description", "image")}),
        ("Play button", {"fields": ("button_text", "game_link")}),
        ("Visibility", {"fields": ("order", "is_published", "created_at")}),
    )

    @admin.display(description="Cover")
    def preview(self, obj):
        if obj.image:
            return format_html(
                '<img src="{}" alt="" style="width:54px;height:54px;object-fit:cover;border-radius:10px;">',
                obj.image.url,
            )
        return "—"
