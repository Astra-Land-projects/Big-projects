from django.apps import AppConfig


class MinigamesConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "minigames"
    verbose_name = "Astra Mini Game"
