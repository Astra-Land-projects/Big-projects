from django.core.exceptions import ValidationError
from django.db import models
from django.utils.text import slugify

from core.validators import validate_image_file


def validate_game_link(value):
    """Accept a full http(s) address or a path on this site such as /static/games/maze.html."""
    value = (value or "").strip()
    if value.startswith(("http://", "https://")) and len(value) > 10 and " " not in value:
        return
    if value.startswith("/") and not value.startswith("//") and " " not in value:
        return
    raise ValidationError("Enter a full link starting with http:// or https://, or a site path starting with /.")


class Game(models.Model):
    """A game shown on the Astra Mini Game page. Managed entirely from Django Admin."""

    title = models.CharField(max_length=120, help_text="The game name, for example: Backrooms.")
    slug = models.SlugField(max_length=140, unique=True, blank=True)
    description = models.TextField(blank=True, help_text="A short description shown on the game card.")
    image = models.ImageField(
        upload_to="minigames/",
        blank=True,
        null=True,
        validators=[validate_image_file],
        help_text="Cover image shown on the game card.",
    )
    button_text = models.CharField(max_length=30, default="Play", help_text="The text on the card button.")
    game_link = models.CharField(
        max_length=300,
        validators=[validate_game_link],
        help_text="Where the Play button goes. Paste the full link to your game.",
    )
    order = models.PositiveIntegerField(default=0, help_text="Lower numbers appear first.")
    is_published = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["order", "-created_at"]
        verbose_name = "Game"
        verbose_name_plural = "Games"

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(self.title) or "astra-game"
            candidate = base_slug
            suffix = 2
            while Game.objects.filter(slug=candidate).exclude(pk=self.pk).exists():
                candidate = f"{base_slug}-{suffix}"
                suffix += 1
            self.slug = candidate
        super().save(*args, **kwargs)
