from django.urls import path

from . import views

app_name = "minigames"

urlpatterns = [
    path("", views.game_list, name="list"),
]
