from django.db.models import Q
from django.shortcuts import render

from .models import Game


def game_list(request):
    query = request.GET.get("q", "").strip()
    games = Game.objects.filter(is_published=True)
    if query:
        games = games.filter(Q(title__icontains=query) | Q(description__icontains=query))
    return render(request, "minigames/game_list.html", {"games": games, "query": query})
