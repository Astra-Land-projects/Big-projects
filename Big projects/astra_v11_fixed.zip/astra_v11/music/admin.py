from django.contrib import admin
from django.db.models import Count

from .models import MusicCategory, Song


@admin.register(MusicCategory)
class MusicCategoryAdmin(admin.ModelAdmin):
    list_display = ("full_path", "parent", "icon", "song_total", "order", "is_published")
    list_editable = ("order", "is_published")
    list_filter = ("is_published",)
    search_fields = ("name", "full_path")
    ordering = ("full_path",)
    fieldsets = (
        (
            "Category",
            {
                "description": (
                    "Build your own music tree. Create a top-level category such as <strong>Persian</strong> "
                    "or <strong>English</strong>, then add deeper levels by choosing a parent, for example "
                    "<em>Persian › Sad › Traditional</em> or <em>English › Rock</em>."
                ),
                "fields": ("name", "parent", "icon"),
            },
        ),
        ("Display", {"fields": ("order", "is_published")}),
    )

    def get_queryset(self, request):
        return super().get_queryset(request).select_related("parent").annotate(_song_total=Count("songs"))

    @admin.display(description="Songs", ordering="_song_total")
    def song_total(self, obj):
        return obj._song_total


@admin.register(Song)
class SongAdmin(admin.ModelAdmin):
    list_display = ("title", "artist", "category", "order", "is_published", "created_at")
    list_editable = ("order", "is_published")
    list_filter = ("is_published", "category")
    search_fields = ("title", "artist", "category__full_path")
    fieldsets = (
        ("Song", {"fields": ("title", "artist", "cover_image", "audio_file")}),
        (
            "Category",
            {
                "description": (
                    "Pick the language first, then the mood and style. Need a new category? "
                    "Use the green + button next to the list, or add it under <em>Music categories</em>."
                ),
                "fields": ("category",),
            },
        ),
        ("Visibility", {"fields": ("order", "is_published")}),
    )

    class Media:
        css = {"all": ("css/astra-admin-music.css",)}
        js = ("js/astra-admin-music.js",)

    def get_queryset(self, request):
        return super().get_queryset(request).select_related("category")
