import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("music", "0001_initial"),
    ]

    operations = [
        migrations.CreateModel(
            name="MusicCategory",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                (
                    "name",
                    models.CharField(
                        help_text="For example: Persian, English, Sad, Happy, Traditional, Rock, Pop.",
                        max_length=60,
                    ),
                ),
                ("slug", models.SlugField(blank=True, max_length=120, unique=True)),
                (
                    "icon",
                    models.CharField(
                        blank=True,
                        help_text="Optional emoji shown on the category chip, for example 🎸.",
                        max_length=8,
                    ),
                ),
                ("order", models.PositiveIntegerField(default=0, help_text="Lower numbers appear first in the category chips.")),
                ("is_published", models.BooleanField(default=True)),
                ("full_path", models.CharField(blank=True, db_index=True, editable=False, max_length=400)),
                (
                    "parent",
                    models.ForeignKey(
                        blank=True,
                        help_text="Leave empty for a top-level category. Choose a parent to create a deeper level.",
                        null=True,
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="children",
                        to="music.musiccategory",
                    ),
                ),
            ],
            options={
                "verbose_name": "Music category",
                "verbose_name_plural": "Music categories",
                "ordering": ["full_path"],
            },
        ),
        migrations.AddField(
            model_name="song",
            name="category",
            field=models.ForeignKey(
                blank=True,
                help_text="Choose the language, mood and style. Songs in the same category are shown together.",
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="songs",
                to="music.musiccategory",
            ),
        ),
    ]
