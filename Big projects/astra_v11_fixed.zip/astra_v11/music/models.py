from django.core.exceptions import ValidationError
from django.db import models
from django.utils.text import slugify

from core.validators import validate_audio_file, validate_image_file

PATH_SEPARATOR = " › "
MAX_CATEGORY_DEPTH = 4


class MusicCategory(models.Model):
    """
    A flexible category tree for Astra Music, managed from Django Admin.

    Example: Persian  >  Sad  >  Traditional        or        English  >  Rock
    A category with no parent is a top-level group (usually a language).
    """

    name = models.CharField(max_length=60, help_text="For example: Persian, English, Sad, Happy, Traditional, Rock, Pop.")
    slug = models.SlugField(max_length=120, unique=True, blank=True)
    parent = models.ForeignKey(
        "self",
        null=True,
        blank=True,
        on_delete=models.CASCADE,
        related_name="children",
        help_text="Leave empty for a top-level category. Choose a parent to create a deeper level.",
    )
    icon = models.CharField(max_length=8, blank=True, help_text="Optional emoji shown on the category chip, for example 🎸.")
    order = models.PositiveIntegerField(default=0, help_text="Lower numbers appear first in the category chips.")
    is_published = models.BooleanField(default=True)
    full_path = models.CharField(max_length=400, blank=True, editable=False, db_index=True)

    class Meta:
        ordering = ["full_path"]
        verbose_name = "Music category"
        verbose_name_plural = "Music categories"

    def __str__(self):
        return self.full_path or self.name

    # ---- tree helpers -------------------------------------------------

    def ancestors(self):
        """Parents from the top-level category down to (but not including) this one."""
        chain = []
        node = self.parent
        guard = 0
        while node is not None and guard < 20:
            chain.append(node)
            node = node.parent
            guard += 1
        chain.reverse()
        return chain

    def compute_path(self):
        names = [node.name for node in self.ancestors()] + [self.name]
        return PATH_SEPARATOR.join(names)

    def descendant_ids(self, include_self=True):
        ids = [self.pk] if include_self else []
        frontier = [self.pk]
        guard = 0
        while frontier and guard < 20:
            frontier = list(MusicCategory.objects.filter(parent_id__in=frontier).values_list("pk", flat=True))
            ids.extend(frontier)
            guard += 1
        return ids

    @property
    def depth(self):
        return len(self.ancestors()) + 1

    # ---- validation / saving -------------------------------------------

    def clean(self):
        super().clean()
        if self.name:
            self.name = self.name.strip()
        if PATH_SEPARATOR.strip() in (self.name or ""):
            raise ValidationError({"name": "The name cannot contain the › character."})
        if self.parent_id:
            if self.pk and self.parent_id == self.pk:
                raise ValidationError({"parent": "A category cannot be its own parent."})
            if self.pk and self.parent_id in self.descendant_ids(include_self=False):
                raise ValidationError({"parent": "A category cannot be moved inside one of its own sub-categories."})
            if self.parent.depth >= MAX_CATEGORY_DEPTH:
                raise ValidationError({"parent": f"Categories can be at most {MAX_CATEGORY_DEPTH} levels deep."})
        siblings = MusicCategory.objects.filter(parent_id=self.parent_id, name__iexact=self.name)
        if self.pk:
            siblings = siblings.exclude(pk=self.pk)
        if self.name and siblings.exists():
            raise ValidationError({"name": "This level already has a category with that name."})

    def save(self, *args, **kwargs):
        self.name = (self.name or "").strip()
        self.full_path = self.compute_path()
        if not self.slug:
            base_slug = slugify(self.full_path.replace(PATH_SEPARATOR, " ")) or "category"
            base_slug = base_slug[:110]
            candidate = base_slug
            suffix = 2
            while MusicCategory.objects.filter(slug=candidate).exclude(pk=self.pk).exists():
                candidate = f"{base_slug}-{suffix}"
                suffix += 1
            self.slug = candidate
        super().save(*args, **kwargs)
        # Keep the stored path of every sub-category in sync after a rename or move.
        for child in self.children.all():
            child.save()


class Song(models.Model):
    title = models.CharField(max_length=150)
    artist = models.CharField(max_length=150, blank=True)
    cover_image = models.ImageField(upload_to="music/covers/", blank=True, null=True, validators=[validate_image_file])
    audio_file = models.FileField(upload_to="music/tracks/", validators=[validate_audio_file])
    category = models.ForeignKey(
        MusicCategory,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="songs",
        help_text="Choose the language, mood and style. Songs in the same category are shown together.",
    )
    order = models.PositiveIntegerField(default=0)
    is_published = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["order", "-created_at"]

    def __str__(self):
        return f"{self.title} — {self.artist}" if self.artist else self.title
