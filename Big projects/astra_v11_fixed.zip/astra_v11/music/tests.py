from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase
from django.urls import reverse

from .models import MusicCategory, Song


def make_song(title, category=None, **extra):
    return Song.objects.create(
        title=title,
        category=category,
        audio_file=SimpleUploadedFile(f"{title}.mp3", b"ID3fake", content_type="audio/mpeg"),
        **extra,
    )


class MusicCategoryModelTests(TestCase):
    def setUp(self):
        self.persian = MusicCategory.objects.create(name="Persian")
        self.sad = MusicCategory.objects.create(name="Sad", parent=self.persian)
        self.traditional = MusicCategory.objects.create(name="Traditional", parent=self.sad)

    def test_full_path_and_slug(self):
        self.assertEqual(self.persian.full_path, "Persian")
        self.assertEqual(self.sad.full_path, "Persian › Sad")
        self.assertEqual(self.traditional.full_path, "Persian › Sad › Traditional")
        self.assertEqual(str(self.traditional), "Persian › Sad › Traditional")
        self.assertTrue(self.traditional.slug)

    def test_rename_updates_children_paths(self):
        self.persian.name = "Iranian"
        self.persian.save()
        self.traditional.refresh_from_db()
        self.assertEqual(self.traditional.full_path, "Iranian › Sad › Traditional")

    def test_descendant_ids(self):
        ids = set(self.persian.descendant_ids())
        self.assertEqual(ids, {self.persian.pk, self.sad.pk, self.traditional.pk})
        self.assertEqual(set(self.sad.descendant_ids(include_self=False)), {self.traditional.pk})

    def test_cannot_move_category_inside_itself(self):
        self.persian.parent = self.traditional
        with self.assertRaises(ValidationError):
            self.persian.full_clean()

    def test_duplicate_name_on_same_level_is_rejected(self):
        duplicate = MusicCategory(name="sad", parent=self.persian)
        with self.assertRaises(ValidationError):
            duplicate.full_clean()

    def test_same_name_allowed_under_different_parents(self):
        english = MusicCategory.objects.create(name="English")
        sad_english = MusicCategory(name="Sad", parent=english)
        sad_english.full_clean()
        sad_english.save()
        self.assertEqual(sad_english.full_path, "English › Sad")
        self.assertNotEqual(sad_english.slug, self.sad.slug)

    def test_depth_limit(self):
        level4 = MusicCategory.objects.create(name="Level4", parent=self.traditional)
        too_deep = MusicCategory(name="Level5", parent=level4)
        with self.assertRaises(ValidationError):
            too_deep.full_clean()


class MusicPageTests(TestCase):
    def setUp(self):
        self.persian = MusicCategory.objects.create(name="Persian")
        self.sad = MusicCategory.objects.create(name="Sad", parent=self.persian)
        self.english = MusicCategory.objects.create(name="English")
        self.rock = MusicCategory.objects.create(name="Rock", parent=self.english)
        make_song("Gham Song", self.sad)
        make_song("Rock Anthem", self.rock)
        make_song("Loose Track")

    def test_page_lists_categories_and_groups(self):
        response = self.client.get(reverse("music:list"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Persian › Sad")
        self.assertContains(response, "English › Rock")
        self.assertContains(response, "More songs")
        self.assertContains(response, "Loose Track")

    def test_filter_by_top_level_includes_sub_categories(self):
        response = self.client.get(reverse("music:list"), {"cat": self.persian.slug})
        self.assertContains(response, "Gham Song")
        self.assertNotContains(response, "Rock Anthem")
        self.assertNotContains(response, "Loose Track")

    def test_filter_by_sub_category(self):
        response = self.client.get(reverse("music:list"), {"cat": self.rock.slug})
        self.assertContains(response, "Rock Anthem")
        self.assertNotContains(response, "Gham Song")

    def test_unknown_category_slug_shows_everything(self):
        response = self.client.get(reverse("music:list"), {"cat": "does-not-exist"})
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Gham Song")

    def test_songs_of_same_category_are_grouped_together(self):
        make_song("Gham Song Two", self.sad)
        response = self.client.get(reverse("music:list"))
        html = response.content.decode()
        first, second = html.index("Gham Song<"), html.index("Gham Song Two<")
        between = html[first:second]
        self.assertNotIn("Rock Anthem", between)
        self.assertNotIn("Loose Track", between)

    def test_search_works_inside_categories(self):
        response = self.client.get(reverse("music:list"), {"q": "rock"})
        self.assertContains(response, "Rock Anthem")
        self.assertNotContains(response, "Gham Song")

    def test_page_without_categories_still_works(self):
        MusicCategory.objects.all().delete()
        response = self.client.get(reverse("music:list"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Gham Song")

    def test_no_new_badge_on_music_page(self):
        response = self.client.get(reverse("music:list"))
        self.assertNotContains(response, "badge-new")
