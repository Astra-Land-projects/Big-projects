from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("newsroom", "0001_initial"),
    ]

    operations = [
        migrations.AddField(
            model_name="article",
            name="kind",
            field=models.CharField(
                choices=[("news", "News"), ("article", "Article"), ("project", "Project")],
                default="news",
                help_text="Choose what you are adding first: a news post, an article, or a project.",
                max_length=10,
            ),
        ),
        migrations.AddField(
            model_name="article",
            name="topic",
            field=models.CharField(
                blank=True,
                help_text="Articles only: the subject of the article, for example Machine Learning.",
                max_length=120,
            ),
        ),
        migrations.AddField(
            model_name="article",
            name="project_url",
            field=models.URLField(blank=True, help_text="Projects only: link to the live site or demo.", max_length=300),
        ),
        migrations.AddField(
            model_name="article",
            name="source_url",
            field=models.URLField(
                blank=True,
                help_text="Projects only (optional): link to the source code, for example GitHub.",
                max_length=300,
            ),
        ),
    ]
