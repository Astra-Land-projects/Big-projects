from django.db import models
from django.urls import reverse
from django.utils.text import slugify


class Article(models.Model):
    """One model for everything published under Astra News: news, articles and projects."""

    class Kind(models.TextChoices):
        NEWS = "news", "News"
        ARTICLE = "article", "Article"
        PROJECT = "project", "Project"

    class Category(models.TextChoices):
        BREAKING = "breaking", "Breaking News"
        BRAND = "brand", "Brand News"
        AI = "ai", "AI News"
        TECH = "tech", "Technology News"

    kind = models.CharField(
        max_length=10,
        choices=Kind.choices,
        default=Kind.NEWS,
        help_text="Choose what you are adding first: a news post, an article, or a project.",
    )
    title = models.CharField(max_length=200)
    slug = models.SlugField(max_length=220, unique=True, blank=True)
    excerpt = models.CharField(max_length=250, blank=True)
    body = models.TextField(blank=True)
    topic = models.CharField(max_length=120, blank=True, help_text="Articles only: the subject of the article, for example Machine Learning.")
    image = models.ImageField(upload_to="news/", blank=True, null=True)
    project_url = models.URLField(max_length=300, blank=True, help_text="Projects only: link to the live site or demo.")
    source_url = models.URLField(max_length=300, blank=True, help_text="Projects only (optional): link to the source code, for example GitHub.")
    category = models.CharField(max_length=20, choices=Category.choices, default=Category.BREAKING)
    is_featured = models.BooleanField(default=False)
    is_published = models.BooleanField(default=True)
    views_count = models.PositiveIntegerField(default=0, editable=False, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.title, allow_unicode=True)
        if self.kind != self.Kind.NEWS:
            # Only news posts can be the featured story on the Astra News page.
            self.is_featured = False
        super().save(*args, **kwargs)

    @property
    def is_news(self):
        return self.kind == self.Kind.NEWS

    @property
    def is_article(self):
        return self.kind == self.Kind.ARTICLE

    @property
    def is_project(self):
        return self.kind == self.Kind.PROJECT

    @property
    def button_label(self):
        return "View Details" if self.is_project else "Read More"

    def get_absolute_url(self):
        return reverse("newsroom:detail", kwargs={"slug": self.slug})
