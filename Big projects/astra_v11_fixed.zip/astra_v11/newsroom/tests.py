from django.test import TestCase
from django.urls import reverse

from .models import Article


class NewsKindsTests(TestCase):
    def setUp(self):
        self.news = Article.objects.create(title="Big AI News", excerpt="News excerpt", category="ai", is_featured=True)
        self.article = Article.objects.create(
            title="Intro to Neural Nets", kind="article", topic="Machine Learning",
            excerpt="A friendly summary", body="Line one.\n\nLine two.",
        )
        self.project = Article.objects.create(
            title="Astra Coin", kind="project", excerpt="A tap game", body="Full project description.",
            project_url="https://example.com/live", source_url="https://github.com/example/astra",
        )

    def test_existing_news_behaviour_is_unchanged(self):
        self.assertEqual(self.news.kind, "news")
        response = self.client.get(reverse("newsroom:list"))
        self.assertContains(response, "Big AI News")
        self.assertContains(response, "Featured News")

    def test_list_shows_articles_and_projects_sections(self):
        response = self.client.get(reverse("newsroom:list"))
        self.assertContains(response, "Intro to Neural Nets")
        self.assertContains(response, "Machine Learning")
        self.assertContains(response, "Astra Coin")
        self.assertContains(response, ">Articles<")
        self.assertContains(response, ">Projects<")

    def test_type_filter(self):
        response = self.client.get(reverse("newsroom:list"), {"type": "project"})
        self.assertContains(response, "Astra Coin")
        self.assertNotContains(response, "Intro to Neural Nets")
        self.assertNotContains(response, "Big AI News")
        response = self.client.get(reverse("newsroom:list"), {"type": "article"})
        self.assertContains(response, "Intro to Neural Nets")
        self.assertNotContains(response, "Astra Coin")

    def test_invalid_type_falls_back_to_all(self):
        response = self.client.get(reverse("newsroom:list"), {"type": "bogus"})
        self.assertContains(response, "Astra Coin")
        self.assertContains(response, "Big AI News")

    def test_search_covers_topic(self):
        response = self.client.get(reverse("newsroom:list"), {"q": "Machine Learning"})
        self.assertContains(response, "Intro to Neural Nets")
        self.assertNotContains(response, "Astra Coin")

    def test_article_detail_page(self):
        response = self.client.get(self.article.get_absolute_url())
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "A friendly summary")
        self.assertContains(response, "Line two.")
        self.assertContains(response, "application/ld+json")

    def test_project_detail_has_view_and_source_buttons(self):
        response = self.client.get(self.project.get_absolute_url())
        self.assertContains(response, "https://example.com/live")
        self.assertContains(response, "View Project")
        self.assertContains(response, "https://github.com/example/astra")
        self.assertContains(response, "Source Code")

    def test_article_detail_tracks_views_and_news_trending_is_dynamic(self):
        from django.contrib.auth import get_user_model
        from astragram.models import Post
        member = get_user_model().objects.create_user(username="trend_member", password="Safe-Test-Password-2026!")
        trending = Article.objects.create(title="Fresh update", excerpt="Astra #AstraAI", body="More about #Django and #AstraAI")
        Post.objects.create(author=member, caption="Building #Django with #AstraAI")
        self.client.get(trending.get_absolute_url())
        self.client.get(trending.get_absolute_url())
        trending.refresh_from_db()
        self.assertEqual(trending.views_count, 2)
        response = self.client.get(reverse("newsroom:list"))
        self.assertContains(response, "What's Trending")
        self.assertContains(response, "#astraai")
        self.assertContains(response, "#django")
        self.assertContains(response, "2 views")

    def test_project_without_links_has_no_buttons(self):
        bare = Article.objects.create(title="Bare Project", kind="project", body="Text")
        response = self.client.get(bare.get_absolute_url())
        self.assertNotContains(response, "View Project")

    def test_only_news_can_be_featured(self):
        featured_article = Article.objects.create(title="Try Featured", kind="article", is_featured=True)
        featured_article.refresh_from_db()
        self.assertFalse(featured_article.is_featured)

    def test_unpublished_items_are_hidden(self):
        Article.objects.create(title="Hidden Draft", kind="article", is_published=False)
        response = self.client.get(reverse("newsroom:list"))
        self.assertNotContains(response, "Hidden Draft")
        self.assertEqual(self.client.get(reverse("newsroom:detail", args=["hidden-draft"])).status_code, 404)

    def test_card_button_labels(self):
        self.assertEqual(self.article.button_label, "Read More")
        self.assertEqual(self.project.button_label, "View Details")
