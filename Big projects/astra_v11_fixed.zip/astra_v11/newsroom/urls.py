from django.urls import path

from . import views

app_name = "newsroom"

urlpatterns = [
    path("", views.news_list, name="list"),
    path("<slug:slug>/", views.article_detail, name="detail"),
]
