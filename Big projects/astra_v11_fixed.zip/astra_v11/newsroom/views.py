import re
from collections import Counter
from datetime import timedelta

from django.db.models import F, Q
from django.shortcuts import get_object_or_404, render
from django.utils import timezone

from .models import Article

SECTION_PREVIEW = 6
FILTERED_LIMIT = 60
VALID_TYPES = {Article.Kind.NEWS.value, Article.Kind.ARTICLE.value, Article.Kind.PROJECT.value}
HASHTAG_PATTERN = re.compile(r"(?<!\w)#([\w-]{2,32})", re.UNICODE)


def _trending_data(published):
    """Build real trends from the last 30 days of published News and public Astragram captions."""
    counts = Counter()
    display_labels = {}
    cutoff = timezone.now() - timedelta(days=30)
    recent = published.filter(created_at__gte=cutoff)
    content_rows = recent.values_list("title", "excerpt", "body", "topic")[:400]
    for title, excerpt, body, topic in content_rows:
        text = " ".join((title or "", excerpt or "", body or ""))
        for match in HASHTAG_PATTERN.findall(text):
            key = match.casefold()
            counts[key] += 1
            display_labels.setdefault(key, f"#{match}")
        if topic and not HASHTAG_PATTERN.search(topic):
            key = topic.strip().casefold()
            counts[key] += 1
            display_labels.setdefault(key, topic.strip())

    from astragram.models import Post
    captions = Post.objects.filter(is_visible=True, created_at__gte=cutoff).values_list("caption", flat=True)[:500]
    for caption in captions:
        for match in HASHTAG_PATTERN.findall(caption or ""):
            key = match.casefold()
            counts[key] += 1
            display_labels.setdefault(key, f"#{match}")

    return [
        {"label": display_labels.get(label, label), "query": label, "count": count}
        for label, count in counts.most_common(10)
    ]


def news_list(request):
    query = request.GET.get("q", "").strip()[:120]
    view_type = request.GET.get("type", "").strip()
    if view_type not in VALID_TYPES:
        view_type = ""

    published = Article.objects.filter(is_published=True)
    if query:
        clean_query = query.lstrip("#")
        published = published.filter(
            Q(title__icontains=clean_query)
            | Q(excerpt__icontains=clean_query)
            | Q(body__icontains=clean_query)
            | Q(topic__icontains=clean_query)
            | Q(category__icontains=clean_query)
        )

    news = published.filter(kind=Article.Kind.NEWS)
    featured = news.filter(is_featured=True).first() if view_type in ("", "news") else None

    sections = []
    if view_type in ("", "news"):
        for key, label in Article.Category.choices:
            section_articles = news.filter(category=key)
            if featured:
                section_articles = section_articles.exclude(pk=featured.pk)
            sections.append((label, section_articles[: SECTION_PREVIEW if not view_type else FILTERED_LIMIT]))

    limit = FILTERED_LIMIT if view_type else SECTION_PREVIEW
    articles = published.filter(kind=Article.Kind.ARTICLE)[:limit] if view_type in ("", "article") else []
    projects = published.filter(kind=Article.Kind.PROJECT)[:limit] if view_type in ("", "project") else []
    has_any = bool(featured) or any(section_articles for _, section_articles in sections) or bool(articles) or bool(projects)

    trending_topics = _trending_data(Article.objects.filter(is_published=True))
    trending_articles = Article.objects.filter(is_published=True, kind=Article.Kind.NEWS).order_by(
        "-views_count", "-created_at"
    )[:5]

    return render(request, "newsroom/news_list.html", {
        "query": query,
        "view_type": view_type,
        "featured": featured,
        "sections": sections,
        "articles": articles,
        "projects": projects,
        "has_any": has_any,
        "trending_topics": trending_topics,
        "trending_articles": trending_articles,
    })


def article_detail(request, slug):
    article = get_object_or_404(Article, slug=slug, is_published=True)
    Article.objects.filter(pk=article.pk).update(views_count=F("views_count") + 1)
    article.refresh_from_db(fields=["views_count"])
    return render(request, "newsroom/article_detail.html", {"article": article})
