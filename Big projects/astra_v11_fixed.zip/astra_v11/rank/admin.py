from django.contrib import admin
from django.utils import timezone
from django.utils.html import format_html
from .models import RankPeriodPrize, Submission, TopRankRecord
from awards.services import record_rank_submission_score
from awards.models import ScoreEntry
from .services import sync_top_rank_record


@admin.register(Submission)
class SubmissionAdmin(admin.ModelAdmin):
    list_display = ("user", "category", "points", "proof_thumbnail", "status", "created_at")
    list_filter = ("status", "category", "created_at")
    search_fields = ("user__username", "user__email", "note")
    readonly_fields = ("points", "created_at", "proof_preview")
    fields = ("user", "category", "proof_image", "proof_preview", "note", "points", "status", "created_at")
    list_select_related = ("user",)
    actions = ["approve_selected", "reject_selected"]

    @admin.display(description="Proof")
    def proof_thumbnail(self, obj):
        if not obj.proof_image:
            return "—"
        return format_html('<img src="{}" style="width:52px;height:52px;object-fit:cover;border-radius:7px" />', obj.proof_image.url)

    @admin.display(description="Uploaded proof preview")
    def proof_preview(self, obj):
        if not obj or not obj.proof_image:
            return "No proof image uploaded"
        return format_html('<a href="{}" target="_blank" rel="noopener"><img src="{}" style="max-width:380px;max-height:300px;object-fit:contain;border-radius:9px" /></a>', obj.proof_image.url, obj.proof_image.url)

    def save_model(self, request, obj, form, change):
        old_status = None
        if change:
            old_status = Submission.objects.filter(pk=obj.pk).values_list("status", flat=True).first()
        super().save_model(request, obj, form, change)
        self._sync_awards_score(obj, old_status)
        sync_top_rank_record()

    def _sync_awards_score(self, obj, old_status):
        key = f"rank:{obj.pk}"
        if obj.status == Submission.Status.APPROVED:
            record_rank_submission_score(obj)
        elif old_status == Submission.Status.APPROVED:
            ScoreEntry.objects.filter(source_key=key).update(points=0)

    @admin.action(description="Approve selected proof submissions and credit Astra Awards")
    def approve_selected(self, request, queryset):
        for obj in queryset.select_related("user"):
            old = obj.status
            obj.status = Submission.Status.APPROVED
            obj.save(update_fields=["status"])
            self._sync_awards_score(obj, old)
        sync_top_rank_record()

    @admin.action(description="Reject selected proof submissions")
    def reject_selected(self, request, queryset):
        for obj in queryset:
            old = obj.status
            obj.status = Submission.Status.REJECTED
            obj.save(update_fields=["status"])
            self._sync_awards_score(obj, old)
        sync_top_rank_record()


@admin.register(TopRankRecord)
class TopRankRecordAdmin(admin.ModelAdmin):
    list_display = ("user", "since", "ended_at", "is_current")
    list_filter = ("ended_at",)
    search_fields = ("user__username",)
    readonly_fields = ("user", "since", "ended_at")
    def has_add_permission(self, request): return False
    def has_delete_permission(self, request, obj=None): return False


@admin.register(RankPeriodPrize)
class RankPeriodPrizeAdmin(admin.ModelAdmin):
    list_display = ("title", "period_type", "period_start", "user", "score_at_close", "claimed_at")
    list_filter = ("period_type", "claimed_at", "period_start")
    search_fields = ("user__username", "title")
    readonly_fields = ("period_type", "period_start", "period_end", "user", "score_at_close", "awarded_at", "claimed_at", "image_preview")
    fields = ("period_type", "period_start", "period_end", "user", "title", "icon", "image", "image_preview", "score_at_close", "awarded_at", "claimed_at")

    @admin.display(description="Prize image preview")
    def image_preview(self, obj):
        if not obj or not obj.image:
            return "No prize image uploaded"
        return format_html('<a href="{}" target="_blank" rel="noopener"><img src="{}" style="max-width:320px;max-height:220px;object-fit:contain;border-radius:8px" /></a>', obj.image.url, obj.image.url)

    def has_add_permission(self, request): return False
    def has_delete_permission(self, request, obj=None): return False
