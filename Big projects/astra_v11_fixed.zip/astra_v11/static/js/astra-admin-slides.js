/*
 * ASTRA v10 - Django Admin helper for Home Slides.
 * Shows the video fields only when the slide type is "Video".
 * Without this script every field stays visible and saving still works.
 */
(function () {
    "use strict";

    function currentType() {
        var checked = document.querySelector('input[name="media_type"]:checked');
        if (checked) { return checked.value; }
        var select = document.querySelector('select[name="media_type"]');
        return select ? select.value : "image";
    }

    function apply() {
        var isVideo = currentType() === "video";
        ["video", "video_autoplay", "video_sound"].forEach(function (name) {
            var row = document.querySelector(".form-row.field-" + name);
            if (row) { row.style.display = isVideo ? "" : "none"; }
        });
        var imageLabel = document.querySelector('label[for="id_image"]');
        if (imageLabel) { imageLabel.textContent = isVideo ? "Poster image (optional):" : "Image:"; }
    }

    function init() {
        document.querySelectorAll('input[name="media_type"], select[name="media_type"]').forEach(function (input) {
            input.addEventListener("change", apply);
        });
        apply();
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init);
    } else {
        init();
    }
})();
