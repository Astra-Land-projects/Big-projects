document.addEventListener("DOMContentLoaded", function () {
    /* ---------- Home slider (auto-rotating, images and videos) ---------- */
    var track = document.getElementById("sliderTrack");
    var dotsWrap = document.getElementById("sliderDots");
    if (track) {
        var slides = track.children;
        var count = slides.length;
        var index = 0;
        var timer = null;
        var sliderInView = true;

        if (dotsWrap) {
            for (var i = 0; i < count; i++) {
                var dot = document.createElement("button");
                dot.className = "slider-dot" + (i === 0 ? " active" : "");
                dot.addEventListener("click", (function (idx) {
                    return function () { goToSlide(idx); };
                })(i));
                dotsWrap.appendChild(dot);
            }
        }

        function videoOf(i) {
            return slides[i] ? slides[i].querySelector("video.slide-video") : null;
        }

        function usesAutoplay(video) {
            return !!video && video.getAttribute("data-autoplay") === "1" && !video.getAttribute("data-failed");
        }

        function updateSoundButton(video) {
            var btn = video && video.parentNode ? video.parentNode.querySelector(".slide-sound-btn") : null;
            if (!btn) { return; }
            btn.classList.toggle("is-muted", video.muted);
            btn.setAttribute("aria-label", video.muted ? "Turn sound on" : "Turn sound off");
            var icon = btn.querySelector("i");
            if (icon) { icon.className = video.muted ? "fa-solid fa-volume-xmark" : "fa-solid fa-volume-high"; }
        }

        function playVideo(video) {
            if (!video) { return; }
            if (video.getAttribute("data-autoplay") !== "1") {
                video.controls = true;          // autoplay is off: the visitor presses play
                updateSoundButton(video);
                return;
            }
            var wantsSound = video.getAttribute("data-sound") === "1" && !video.hasAttribute("data-user-muted");
            video.muted = !wantsSound;
            video.loop = count < 2;             // with several slides, move on when the video ends
            var attempt = video.play();
            if (attempt && attempt.catch) {
                attempt.catch(function () {
                    // The browser blocked playback with sound: keep playing silently, the sound button stays visible.
                    video.muted = true;
                    var silent = video.play();
                    if (silent && silent.catch) { silent.catch(function () {}); }
                    updateSoundButton(video);
                });
            }
            updateSoundButton(video);
        }

        function stopVideo(video) {
            if (video && !video.paused) { video.pause(); }
        }

        function schedule() {
            clearTimeout(timer);
            if (count < 2) { return; }
            // A playing video decides when to move on (see the "ended" listener); 2 minutes is only a safety limit.
            timer = setTimeout(next, usesAutoplay(videoOf(index)) ? 120000 : 5000);
        }

        function next() {
            goToSlide((index + 1) % count);
        }

        function goToSlide(i) {
            stopVideo(videoOf(index));
            index = i;
            track.style.transform = "translateX(-" + (index * 100) + "%)";
            if (dotsWrap) {
                Array.prototype.forEach.call(dotsWrap.children, function (d, di) {
                    d.classList.toggle("active", di === index);
                });
            }
            if (sliderInView && !document.hidden) { playVideo(videoOf(index)); }
            schedule();
        }

        Array.prototype.forEach.call(track.querySelectorAll("video.slide-video"), function (video) {
            video.addEventListener("ended", function () {
                if (count > 1 && videoOf(index) === video) { next(); }
            });
            video.addEventListener("error", function () {
                video.setAttribute("data-failed", "1");
                if (videoOf(index) === video) { schedule(); }
            });
        });

        Array.prototype.forEach.call(track.querySelectorAll(".slide-sound-btn"), function (btn) {
            btn.addEventListener("click", function (event) {
                event.stopPropagation();
                var video = btn.parentNode.querySelector("video.slide-video");
                if (!video) { return; }
                video.muted = !video.muted;
                if (video.muted) { video.setAttribute("data-user-muted", "1"); }
                else { video.removeAttribute("data-user-muted"); }
                if (video.paused && video.getAttribute("data-autoplay") === "1") {
                    var resume = video.play();
                    if (resume && resume.catch) { resume.catch(function () {}); }
                }
                updateSoundButton(video);
            });
        });

        // Browsers only allow sound after the visitor interacts with the page: switch it on at the first touch or click.
        function unlockSound() {
            var video = videoOf(index);
            if (video && video.muted && video.getAttribute("data-sound") === "1" && !video.hasAttribute("data-user-muted")) {
                video.muted = false;
                updateSoundButton(video);
            }
        }
        ["click", "touchstart", "keydown"].forEach(function (name) {
            document.addEventListener(name, function handler() {
                document.removeEventListener(name, handler);
                unlockSound();
            }, { passive: true });
        });

        // Pause when the tab is hidden or the slider is scrolled out of view.
        document.addEventListener("visibilitychange", function () {
            var video = videoOf(index);
            if (document.hidden) { stopVideo(video); }
            else if (sliderInView) { playVideo(video); }
        });
        var sliderEl = document.getElementById("heroSlider");
        if (sliderEl && "IntersectionObserver" in window) {
            new IntersectionObserver(function (entries) {
                sliderInView = entries[0].isIntersecting;
                var video = videoOf(index);
                if (sliderInView && !document.hidden) { playVideo(video); } else { stopVideo(video); }
            }, { threshold: 0.25 }).observe(sliderEl);
        }

        playVideo(videoOf(0));
        schedule();
    }
});

document.addEventListener("DOMContentLoaded", function () {
    /* ---------- Off-canvas side menu ---------- */
    var menuToggle = document.getElementById("menuToggle");
    var menuClose = document.getElementById("menuClose");
    var sideMenu = document.getElementById("sideMenu");
    var backdrop = document.getElementById("menuBackdrop");

    function openMenu() {
        if (sideMenu) sideMenu.classList.add("open");
        if (backdrop) backdrop.hidden = false;
    }

    function closeMenu() {
        if (sideMenu) sideMenu.classList.remove("open");
        if (backdrop) backdrop.hidden = true;
    }

    if (menuToggle) menuToggle.addEventListener("click", openMenu);
    if (menuClose) menuClose.addEventListener("click", closeMenu);
    if (backdrop) backdrop.addEventListener("click", closeMenu);

    /* ---------- Support widget ---------- */
    var toggle = document.getElementById("supportToggle");
    var panel = document.getElementById("supportPanel");
    var openAiChat = document.getElementById("openAiChat");
    var aiChat = document.getElementById("aiChat");
    var chatForm = document.getElementById("aiChatForm");
    var chatInput = document.getElementById("aiChatInput");
    var chatLog = document.getElementById("aiChatLog");

    if (toggle && panel) {
        toggle.addEventListener("click", function () {
            panel.hidden = !panel.hidden;
        });
    }

    if (openAiChat && aiChat) {
        openAiChat.addEventListener("click", function () {
            aiChat.hidden = !aiChat.hidden;
        });
    }

    function getCookie(name) {
        var value = "; " + document.cookie;
        var parts = value.split("; " + name + "=");
        if (parts.length === 2) return parts.pop().split(";").shift();
        return "";
    }

    if (chatForm) {
        chatForm.addEventListener("submit", function (e) {
            e.preventDefault();
            var message = chatInput.value.trim();
            if (!message) return;

            appendMessage(message, "user");
            chatInput.value = "";

            fetch("/astra-ai/chat/", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-CSRFToken": getCookie("csrftoken"),
                },
                body: JSON.stringify({ message: message }),
            })
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    appendMessage(data.reply || "Sorry, I can't answer that right now.", "bot");
                })
                .catch(function () {
                    appendMessage("Connection problem, please try again.", "bot");
                });
        });
    }

    function appendMessage(text, who) {
        if (!chatLog) return;
        var el = document.createElement("div");
        el.className = "ai-msg " + who;
        el.textContent = text;
        chatLog.appendChild(el);
        chatLog.scrollTop = chatLog.scrollHeight;
    }
});

document.addEventListener("DOMContentLoaded", function () {
    var revealSelectors = ".content-card, .value-card, .timeline-item, .stat-card, .info-box, .contact-shortcut";
    var revealEls = document.querySelectorAll(revealSelectors);

    if ("IntersectionObserver" in window) {
        var observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add("visible");
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.15 });

        revealEls.forEach(function (el) { observer.observe(el); });
    } else {
        // Old browsers without IntersectionObserver: just show everything.
        revealEls.forEach(function (el) { el.classList.add("visible"); });
    }
});