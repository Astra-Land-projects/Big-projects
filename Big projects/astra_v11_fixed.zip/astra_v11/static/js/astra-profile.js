// ==========================
// PAGE LOAD ANIMATION
// ==========================

window.addEventListener("load", () => {

    const container = document.querySelector(".profile-container");
    if (container) {
        container.style.opacity = "1";
        container.style.transform = "translateY(0)";
    }

});

// ==========================
// AVATAR PREVIEW
// (uses the REAL form input so the file is actually submitted —
// previously this created a separate, detached input that only
// updated the preview and never reached the server)
// ==========================

const avatarInput = document.querySelector('input[name="avatar"]');
const avatarImage = document.querySelector(".avatar");

if (avatarInput && avatarImage) {
    avatarInput.addEventListener("change", (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function (event) {
                avatarImage.src = event.target.result;
            };
            reader.readAsDataURL(file);
        }
    });
}

// ==========================
// BANNER PREVIEW (same fix as avatar above)
// ==========================

const bannerInput = document.querySelector('input[name="banner"]');
const banner = document.querySelector(".banner");

if (bannerInput && banner) {
    bannerInput.addEventListener("change", (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function (event) {
                banner.style.backgroundImage = `url(${event.target.result})`;
                banner.style.backgroundSize = "cover";
                banner.style.backgroundPosition = "center";
            };
            reader.readAsDataURL(file);
        }
    });
}

// ==========================
// SAVE BUTTON (cosmetic only — the form still submits normally)
// ==========================

const saveBtn = document.querySelector(".save-btn");

if (saveBtn) {
    saveBtn.addEventListener("click", () => {
        saveBtn.innerText = "Saving...";
        saveBtn.style.opacity = ".8";
        // No preventDefault — the real form submission proceeds normally.
    });
}

// ==========================
// INPUT EFFECTS
// ==========================

document
    .querySelectorAll("input, textarea, select")
    .forEach(el => {
        el.addEventListener("focus", () => {
            if (el.parentElement) el.parentElement.style.transform = "translateY(-2px)";
        });
        el.addEventListener("blur", () => {
            if (el.parentElement) el.parentElement.style.transform = "translateY(0)";
        });
    });
