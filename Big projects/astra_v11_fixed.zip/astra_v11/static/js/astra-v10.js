/*
 * ASTRA v10 - motion layer.
 * Adds scroll reveal, a progress bar, a back-to-top button, a soft star background,
 * card tilt, number counters and a staggered side menu. Nothing here changes content.
 * If anything fails, the page simply stays as it was in earlier versions.
 */
(function () {
    "use strict";

    var reduceMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    var finePointer = window.matchMedia && window.matchMedia("(hover: hover) and (pointer: fine)").matches;

    /* Elements that already have their own reveal code are NOT listed here. */
    var REVEAL_SELECTOR = [
        ".card", ".why-card", ".stat-box", ".help-card", ".faq-item", ".info-card", ".astra-card", ".game-card",
        ".astra-post", ".event-card", ".award-section", ".points-card", ".music-group", ".rank-table-wrap",
        ".clock-card", ".calendar-card", ".utc-card", ".contact-form", ".new-post-form", ".profile-card", "[data-animate]"
    ].join(",");

    var TILT_SELECTOR = ".card, .why-card, .help-card, .game-card";

    function ready(fn) {
        if (document.readyState === "loading") { document.addEventListener("DOMContentLoaded", fn); }
        else { fn(); }
    }

    /* ---------------- scroll reveal ---------------- */
    function initReveal() {
        if (reduceMotion || !("IntersectionObserver" in window)) { return; }
        var items = Array.prototype.slice.call(document.querySelectorAll(REVEAL_SELECTOR));
        if (!items.length) { return; }

        var pending = [];
        var viewportBottom = window.innerHeight || document.documentElement.clientHeight;

        function show(el, index) {
            if (!el.classList.contains("v10-pre")) { return; }
            el.style.setProperty("--v10-delay", Math.min(index, 6) * 70 + "ms");
            el.classList.remove("v10-pre");
            el.classList.add("v10-show");
            setTimeout(function () {
                el.classList.remove("v10-show");
                el.style.removeProperty("--v10-delay");
            }, 1300);
        }

        var observer = new IntersectionObserver(function (entries) {
            var batch = 0;
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    show(entry.target, batch++);
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });

        items.forEach(function (el) {
            var rect = el.getBoundingClientRect();
            if (rect.top > viewportBottom) {
                el.classList.add("v10-pre");
                pending.push(el);
                observer.observe(el);
            }
        });

        // Safety net: never leave anything invisible (for example if the tab was in the background).
        setTimeout(function () {
            pending.forEach(function (el) { el.classList.remove("v10-pre"); });
        }, 6000);
    }

    /* ---------------- progress bar, top bar shadow, back to top ---------------- */
    function initScrollUi() {
        var bar = document.createElement("div");
        bar.id = "v10-progress";
        bar.setAttribute("aria-hidden", "true");
        document.body.appendChild(bar);

        var topBtn = document.createElement("button");
        topBtn.id = "v10-top";
        topBtn.type = "button";
        topBtn.setAttribute("aria-label", "Back to top");
        topBtn.innerHTML = "&#8593;";
        topBtn.addEventListener("click", function () {
            window.scrollTo({ top: 0, behavior: reduceMotion ? "auto" : "smooth" });
        });
        document.body.appendChild(topBtn);

        var topbar = document.querySelector(".astra-topbar");
        var ticking = false;

        function update() {
            ticking = false;
            var doc = document.documentElement;
            var max = (doc.scrollHeight - doc.clientHeight) || 1;
            var y = window.pageYOffset || doc.scrollTop || 0;
            bar.style.width = Math.min(100, (y / max) * 100) + "%";
            topBtn.classList.toggle("v10-visible", y > 600);
            if (topbar) { topbar.classList.toggle("v10-scrolled", y > 8); }
        }

        window.addEventListener("scroll", function () {
            if (!ticking) { ticking = true; window.requestAnimationFrame(update); }
        }, { passive: true });
        update();
    }

    /* ---------------- card tilt ---------------- */
    function initTilt() {
        if (reduceMotion || !finePointer) { return; }
        document.querySelectorAll(TILT_SELECTOR).forEach(function (card) {
            card.addEventListener("pointermove", function (event) {
                var rect = card.getBoundingClientRect();
                var x = (event.clientX - rect.left) / rect.width - 0.5;
                var y = (event.clientY - rect.top) / rect.height - 0.5;
                card.style.setProperty("--v10-ry", (x * 7).toFixed(2) + "deg");
                card.style.setProperty("--v10-rx", (-y * 7).toFixed(2) + "deg");
                card.classList.add("v10-tilting");
            });
            card.addEventListener("pointerleave", function () {
                card.classList.remove("v10-tilting");
                card.style.removeProperty("--v10-rx");
                card.style.removeProperty("--v10-ry");
            });
        });
    }

    /* ---------------- number counters (home stats) ---------------- */
    function initCounters() {
        if (reduceMotion || !("IntersectionObserver" in window)) { return; }
        var targets = [];
        document.querySelectorAll(".stat-box h3").forEach(function (el) {
            var match = /^(\d+)(\+?)$/.exec(el.textContent.trim());
            if (match) { targets.push({ el: el, value: parseInt(match[1], 10), suffix: match[2] }); }
        });
        if (!targets.length) { return; }

        var observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (!entry.isIntersecting) { return; }
                observer.unobserve(entry.target);
                var target = targets.filter(function (t) { return t.el === entry.target; })[0];
                if (!target) { return; }
                var start = null;
                var duration = 1400;
                function step(now) {
                    if (start === null) { start = now; }
                    var progress = Math.min(1, (now - start) / duration);
                    var eased = 1 - Math.pow(1 - progress, 3);
                    target.el.textContent = Math.round(target.value * eased) + target.suffix;
                    if (progress < 1) { window.requestAnimationFrame(step); }
                }
                window.requestAnimationFrame(step);
            });
        }, { threshold: 0.6 });
        targets.forEach(function (t) { observer.observe(t.el); });
    }

    /* ---------------- side menu stagger ---------------- */
    function initMenuStagger() {
        document.querySelectorAll(".side-menu-links li").forEach(function (li, index) {
            li.style.setProperty("--v10-i", String(index));
        });
    }

    /* ---------------- soft star background ---------------- */
    function initStars() {
        if (reduceMotion || !document.createElement("canvas").getContext) { return; }
        var canvas = document.createElement("canvas");
        canvas.id = "v10-stars";
        canvas.setAttribute("aria-hidden", "true");
        document.body.insertBefore(canvas, document.body.firstChild);
        var ctx = canvas.getContext("2d");
        if (!ctx) { return; }

        var width = 0, height = 0, stars = [];
        var small = window.innerWidth < 700;
        var count = small ? 28 : 55;

        function resize() {
            var ratio = Math.min(window.devicePixelRatio || 1, 2);
            width = window.innerWidth;
            height = window.innerHeight;
            canvas.width = Math.floor(width * ratio);
            canvas.height = Math.floor(height * ratio);
            ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
        }

        function seed() {
            stars = [];
            for (var i = 0; i < count; i++) {
                stars.push({
                    x: Math.random() * width,
                    y: Math.random() * height,
                    r: Math.random() * 1.4 + 0.4,
                    speed: Math.random() * 0.12 + 0.03,
                    phase: Math.random() * Math.PI * 2
                });
            }
        }

        resize();
        seed();
        window.addEventListener("resize", function () { resize(); seed(); });

        var last = 0;
        function frame(now) {
            window.requestAnimationFrame(frame);
            if (document.hidden || now - last < 33) { return; }   // about 30 frames per second
            last = now;
            ctx.clearRect(0, 0, width, height);
            for (var i = 0; i < stars.length; i++) {
                var s = stars[i];
                s.y -= s.speed;
                if (s.y < -4) { s.y = height + 4; s.x = Math.random() * width; }
                var twinkle = 0.45 + 0.55 * Math.abs(Math.sin(now / 1100 + s.phase));
                ctx.beginPath();
                ctx.fillStyle = "rgba(245, 193, 108, " + (0.65 * twinkle).toFixed(3) + ")";
                ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
                ctx.fill();
            }
        }
        window.requestAnimationFrame(frame);
    }

    ready(function () {
        var steps = [initMenuStagger, initScrollUi, initReveal, initTilt, initCounters, initStars];
        steps.forEach(function (step) {
            try { step(); } catch (error) { if (window.console) { console.warn("Astra v10 effect skipped:", error); } }
        });
    });
})();
