// ==========================
// FADE IN
// ==========================

window.addEventListener("load", () => {

    const card =
        document.querySelector(".login-card");

    const logo =
        document.querySelector(".logo-area");

    card.style.opacity = "1";
    card.style.transform = "translateY(0)";

    logo.style.opacity = "1";
    logo.style.transform = "translateY(0)";

});

// ==========================
// PASSWORD TOGGLE
// ==========================

const passwordInput =
    document.querySelector(
        'input[type="password"]'
    );

if (passwordInput) {

    const wrapper =
        passwordInput.parentElement;

    const eye =
        document.createElement("span");

    eye.innerHTML =
        '<i class="fa-solid fa-eye"></i>';

    eye.classList.add("eye-toggle");

    wrapper.style.position =
        "relative";

    wrapper.appendChild(eye);

    eye.addEventListener(
        "click",
        () => {

            if (passwordInput.type === "password") {

                passwordInput.type = "text";

                eye.innerHTML =
                    '<i class="fa-solid fa-eye-slash"></i>';

            } else {

                passwordInput.type = "password";

                eye.innerHTML =
                    '<i class="fa-solid fa-eye"></i>';

            }

        }
    );

}

// ==========================
// BUTTON RIPPLE
// ==========================

document
    .querySelectorAll(
        ".login-btn,.google-btn,.github-btn"
    )
    .forEach(btn => {

        btn.addEventListener(
            "click",
            function (e) {

                const ripple =
                    document.createElement("span");

                const rect =
                    this.getBoundingClientRect();

                const size =
                    Math.max(
                        rect.width,
                        rect.height
                    );

                ripple.style.width =
                    size + "px";

                ripple.style.height =
                    size + "px";

                ripple.style.left =
                    e.clientX -
                    rect.left -
                    size / 2 + "px";

                ripple.style.top =
                    e.clientY -
                    rect.top -
                    size / 2 + "px";

                ripple.classList.add("ripple");

                this.appendChild(ripple);

                setTimeout(() => {

                    ripple.remove();

                }, 600);

            }
        );

    });

// ==========================
// INPUT GLOW
// ==========================

document
    .querySelectorAll("input")
    .forEach(input => {

        input.addEventListener(
            "focus",
            () => {

                input.parentElement.style.transform =
                    "translateY(-2px)";

            });

        input.addEventListener(
            "blur",
            () => {

                input.parentElement.style.transform =
                    "translateY(0)";

            });

    });

// ==========================
// LANGUAGE SELECT
// ==========================

const language =
    document.querySelector("select");

if (language) {

    language.addEventListener(
        "change",
        () => {

            console.log(
                "Language:",
                language.value
            );

        }
    );

}

// ==========================
// FLOATING GLOW
// ==========================

let glow =
    document.querySelector(
        ".background-glow"
    );

let mouseX = 0;
let mouseY = 0;

document.addEventListener(
    "mousemove",
    (e) => {

        mouseX = e.clientX;
        mouseY = e.clientY;

        glow.style.background = `

radial-gradient(
circle at ${mouseX}px ${mouseY}px,
rgba(245,193,108,.08),
transparent 250px
),

radial-gradient(
circle at 15% 20%,
rgba(139,92,246,.25),
transparent 30%
),

radial-gradient(
circle at 85% 30%,
rgba(59,130,246,.18),
transparent 35%
)

`;

    }
);