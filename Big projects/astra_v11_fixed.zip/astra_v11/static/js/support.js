// ==========================
// REVEAL ANIMATION
// ==========================

window.addEventListener("load", () => {

    document
        .querySelectorAll(
            ".info-card,.contact-form,.quick-links"
        )
        .forEach((el, index) => {

            setTimeout(() => {

                el.classList.add("show");

            }, index * 120);

        });

});

// ==========================
// FORM SUBMIT
// ==========================

const form =
    document.querySelector("form");

if (form) {

    form.addEventListener(
        "submit",
        () => {

            const button =
                form.querySelector("button");

            button.innerHTML =
                "Sending...";

            button.disabled = true;

            // No preventDefault here — the form submits normally to
            // the server, which redirects back with a confirmation
            // message once it's actually sent/saved.

        });

}

// ==========================
// INPUT FOCUS EFFECT
// ==========================

document
    .querySelectorAll(
        "input, textarea"
    )
    .forEach(field => {

        field.addEventListener(
            "focus",
            () => {

                field.parentElement?.classList?.add(
                    "active"
                );

            });

        field.addEventListener(
            "blur",
            () => {

                field.parentElement?.classList?.remove(
                    "active"
                );

            });

    });