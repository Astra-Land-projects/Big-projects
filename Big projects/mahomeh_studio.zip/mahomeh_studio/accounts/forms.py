from django import forms
from django.contrib.auth import password_validation
from django.contrib.auth.forms import AuthenticationForm

from .models import User


class RegisterForm(forms.ModelForm):
    """Sign-up form: phone + password only. Email/full name are optional.
    On success the account is created and the user is logged in right away —
    no admin approval step, no OTP."""

    password1 = forms.CharField(
        label='رمز عبور', widget=forms.PasswordInput(attrs={'placeholder': 'رمز عبور'}),
        strip=False,
    )
    password2 = forms.CharField(
        label='تکرار رمز عبور', widget=forms.PasswordInput(attrs={'placeholder': 'تکرار رمز عبور'}),
        strip=False,
    )

    class Meta:
        model = User
        fields = ('phone', 'email', 'full_name')
        widgets = {
            'phone': forms.TextInput(attrs={'placeholder': '09123456789', 'dir': 'ltr'}),
            'email': forms.EmailInput(attrs={'placeholder': 'ایمیل (اختیاری — برای بازیابی رمز عبور)', 'dir': 'ltr'}),
            'full_name': forms.TextInput(attrs={'placeholder': 'نام و نام‌خانوادگی (اختیاری)'}),
        }

    def clean_phone(self):
        phone = self.cleaned_data['phone']
        if phone.startswith('+98'):
            phone = '0' + phone[3:]
        if User.objects.filter(phone=phone).exists():
            raise forms.ValidationError('این شماره موبایل قبلاً ثبت‌نام کرده است.')
        return phone

    def clean_password2(self):
        p1 = self.cleaned_data.get('password1')
        p2 = self.cleaned_data.get('password2')
        if p1 and p2 and p1 != p2:
            raise forms.ValidationError('رمز عبور و تکرار آن یکسان نیستند.')
        if p2:
            password_validation.validate_password(p2)
        return p2

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data['password1'])
        if commit:
            user.save()
        return user


class PhoneLoginForm(AuthenticationForm):
    """Same as Django's built-in login form, just relabeled for phone
    numbers and styled to match the site."""

    username = forms.CharField(
        label='شماره موبایل',
        widget=forms.TextInput(attrs={'placeholder': '09123456789', 'dir': 'ltr', 'autofocus': True}),
    )
    password = forms.CharField(
        label='رمز عبور',
        widget=forms.PasswordInput(attrs={'placeholder': 'رمز عبور'}),
    )

    error_messages = {
        **AuthenticationForm.error_messages,
        'invalid_login': 'شماره موبایل یا رمز عبور اشتباه است.',
        'inactive': 'این حساب کاربری غیرفعال شده است.',
    }
