from django.contrib.auth.base_user import AbstractBaseUser, BaseUserManager
from django.contrib.auth.models import PermissionsMixin
from django.core.validators import RegexValidator
from django.db import models

phone_validator = RegexValidator(
    regex=r'^(\+98|0)?9\d{9}$',
    message='شماره موبایل معتبر نیست. مثال درست: 09123456789'
)


class UserManager(BaseUserManager):
    """Manager for the custom User model — phone number is required,
    everything else is optional."""

    use_in_migrations = True

    def _create_user(self, phone, password, **extra_fields):
        if not phone:
            raise ValueError('شماره موبایل الزامی است.')
        # Normalize +989... to 09... so the same number never gets stored twice.
        if phone.startswith('+98'):
            phone = '0' + phone[3:]
        user = self.model(phone=phone, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_user(self, phone, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', False)
        extra_fields.setdefault('is_superuser', False)
        return self._create_user(phone, password, **extra_fields)

    def create_superuser(self, phone, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        if extra_fields.get('is_staff') is not True:
            raise ValueError('ابرکاربر باید is_staff=True داشته باشد.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('ابرکاربر باید is_superuser=True داشته باشد.')
        return self._create_user(phone, password, **extra_fields)


class User(AbstractBaseUser, PermissionsMixin):
    """Custom user: login is done with a phone number + password.

    Registration is instant/automatic (no admin approval step) — as soon as
    someone signs up they are logged in immediately. Admins only use the
    Django admin panel afterwards to manage/deactivate accounts if needed.
    """
    phone = models.CharField(
        'شماره موبایل', max_length=13, unique=True, validators=[phone_validator]
    )
    # Optional — collected only so a "forgot password" reset link has
    # somewhere to go. Registration works fine without it.
    email = models.EmailField('ایمیل (اختیاری)', blank=True, null=True)
    full_name = models.CharField('نام و نام‌خانوادگی', max_length=150, blank=True)

    is_active = models.BooleanField('فعال', default=True)
    is_staff = models.BooleanField('دسترسی به پنل ادمین', default=False)
    date_joined = models.DateTimeField('تاریخ عضویت', auto_now_add=True)

    objects = UserManager()

    USERNAME_FIELD = 'phone'
    REQUIRED_FIELDS = []  # createsuperuser will only prompt for phone + password

    class Meta:
        verbose_name = 'کاربر'
        verbose_name_plural = 'کاربران'
        ordering = ['-date_joined']

    def __str__(self):
        return self.full_name or self.phone

    def get_short_name(self):
        return self.full_name or self.phone
