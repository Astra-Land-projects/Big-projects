from django.contrib.auth import login as auth_login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView, LogoutView
from django.shortcuts import render, redirect

from .forms import RegisterForm, PhoneLoginForm


class PhoneLoginView(LoginView):
    template_name = 'accounts/login.html'
    authentication_form = PhoneLoginForm
    redirect_authenticated_user = True
    extra_context = {
        'meta_title': 'ورود | ماهومه',
        'meta_description': 'ورود به حساب کاربری ماهومه.',
    }


class PhoneLogoutView(LogoutView):
    next_page = 'core:home'


def register(request):
    if request.user.is_authenticated:
        return redirect('accounts:profile')

    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Registration is instant: log the new user in right away,
            # no admin approval step and no verification code required.
            auth_login(request, user)
            return redirect('accounts:profile')
    else:
        form = RegisterForm()

    context = {
        'form': form,
        'meta_title': 'ثبت‌نام | ماهومه',
        'meta_description': 'ساخت حساب کاربری در ماهومه.',
    }
    return render(request, 'accounts/register.html', context)


@login_required
def profile(request):
    context = {
        'meta_title': 'حساب کاربری | ماهومه',
        'meta_description': 'مدیریت حساب کاربری در ماهومه.',
    }
    return render(request, 'accounts/profile.html', context)
