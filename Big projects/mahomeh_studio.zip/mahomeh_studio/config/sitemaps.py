from django.contrib.sitemaps import Sitemap
from django.urls import reverse

from core.models import Project, Article


class StaticViewSitemap(Sitemap):
    """Sitemap entries for pages that are not tied to a database model."""
    priority = 0.7
    changefreq = 'weekly'

    def items(self):
        return ['core:home', 'core:about', 'core:support',
                'accounts:login', 'accounts:register']

    def location(self, item):
        return reverse(item)


class ProjectSitemap(Sitemap):
    priority = 0.6
    changefreq = 'monthly'

    def items(self):
        return Project.objects.filter(is_active=True)

    def lastmod(self, obj):
        return obj.updated_at

    def location(self, obj):
        return reverse('core:project_detail', args=[obj.slug])


class ArticleSitemap(Sitemap):
    priority = 0.6
    changefreq = 'weekly'

    def items(self):
        return Article.objects.filter(is_active=True)

    def lastmod(self, obj):
        return obj.updated_at

    def location(self, obj):
        return reverse('core:article_detail', args=[obj.slug])


sitemaps = {
    'static': StaticViewSitemap,
    'projects': ProjectSitemap,
    'articles': ArticleSitemap,
}
