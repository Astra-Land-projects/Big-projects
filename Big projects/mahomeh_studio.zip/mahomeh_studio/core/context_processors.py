from django.conf import settings


def site_meta(request):
    """Makes site-wide constants (name, domain) available to every template
    without passing them from every single view."""
    return {
        'SITE_NAME': settings.SITE_NAME,
        'SITE_DOMAIN': settings.SITE_DOMAIN,
    }
