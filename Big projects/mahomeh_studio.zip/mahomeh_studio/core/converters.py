class UnicodeSlugConverter:
    """Django's built-in 'slug' path converter only matches ASCII
    (a-z, 0-9, -, _). Since project/article slugs are generated from
    Persian names, we need a converter that also accepts Persian/unicode
    letters — otherwise every detail page would 404.
    """
    regex = r'[-\w]+'

    def to_python(self, value):
        return value

    def to_url(self, value):
        return value
