from django.db import models
from django.urls import reverse
from django.utils.text import slugify


class SliderItem(models.Model):
    """One slide of the automatic home-page hero slider.

    Everything here is manageable from Django admin — no template edits
    needed to add, remove, reorder, or hide a slide.
    """
    title = models.CharField('عنوان', max_length=200)
    caption = models.TextField('توضیح کوتاه', blank=True)
    image = models.ImageField('تصویر', upload_to='slider/')
    link_url = models.CharField(
        'لینک (اختیاری)', max_length=300, blank=True,
        help_text='وقتی کاربر روی این اسلاید کلیک می‌کند به این آدرس برود.'
    )
    order = models.PositiveIntegerField('ترتیب نمایش', default=0)
    is_active = models.BooleanField('فعال', default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'اسلاید'
        verbose_name_plural = 'اسلایدر خانه'
        ordering = ['order', '-created_at']

    def __str__(self):
        return self.title


class Project(models.Model):
    """One entry in the projects bank shown on the home page."""
    name = models.CharField('نام پروژه', max_length=200)
    slug = models.SlugField('اسلاگ (برای آدرس صفحه)', max_length=220, unique=True, blank=True, allow_unicode=True)
    image = models.ImageField('تصویر', upload_to='projects/')
    short_description = models.CharField('توضیح خلاصه', max_length=300)
    main_description = models.TextField('توضیح اصلی (توی صفحه اختصاصی پروژه)')
    external_link = models.URLField(
        'لینک پروژه / گیت‌هاب', blank=True,
        help_text='مثلاً لینک دمو یا ریپازیتوری گیت‌هاب.'
    )
    order = models.PositiveIntegerField('ترتیب نمایش', default=0)
    is_active = models.BooleanField('نمایش در سایت', default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'پروژه'
        verbose_name_plural = 'پروژه‌ها'
        ordering = ['order', '-created_at']

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name, allow_unicode=True)
        super().save(*args, **kwargs)

    def get_absolute_url(self):
        return reverse('core:project_detail', args=[self.slug])


class Article(models.Model):
    """One article/analysis entry shown on the home page."""
    name = models.CharField('عنوان مقاله', max_length=200)
    slug = models.SlugField('اسلاگ (برای آدرس صفحه)', max_length=220, unique=True, blank=True, allow_unicode=True)
    image = models.ImageField('تصویر', upload_to='articles/')
    short_description = models.CharField('توضیح خلاصه', max_length=300)
    main_description = models.TextField('توضیح اصلی (توی صفحه اختصاصی مقاله)')
    published_date = models.DateField('تاریخ انتشار')
    is_active = models.BooleanField('نمایش در سایت', default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'مقاله'
        verbose_name_plural = 'مقالات'
        ordering = ['-published_date']

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name, allow_unicode=True)
        super().save(*args, **kwargs)

    def get_absolute_url(self):
        return reverse('core:article_detail', args=[self.slug])
