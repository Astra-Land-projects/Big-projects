from django.urls import path, register_converter

from . import views
from .converters import UnicodeSlugConverter

register_converter(UnicodeSlugConverter, 'uslug')

app_name = 'core'

urlpatterns = [
    path('', views.home, name='home'),
    path('about/', views.about, name='about'),
    path('support/', views.support, name='support'),
    path('projects/<uslug:slug>/', views.project_detail, name='project_detail'),
    path('articles/<uslug:slug>/', views.article_detail, name='article_detail'),
]
