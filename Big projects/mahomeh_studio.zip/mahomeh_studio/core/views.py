from django.shortcuts import render, get_object_or_404

from .models import SliderItem, Project, Article


def home(request):
    context = {
        'slider_items': SliderItem.objects.filter(is_active=True),
        'projects': Project.objects.filter(is_active=True)[:4],
        'articles': Article.objects.filter(is_active=True)[:3],
        'meta_title': 'ماهومه | هوش مصنوعی به زبانی روشن',
        'meta_description': 'ماهومه؛ استودیویی برای پژوهش، آموزش، رسانه و فناوری در حوزه هوش مصنوعی.',
    }
    return render(request, 'core/home.html', context)


def about(request):
    context = {
        'meta_title': 'درباره ما | ماهومه',
        'meta_description': 'آشنایی با ماهومه، مأموریت و تیم ما.',
    }
    return render(request, 'core/about.html', context)


def support(request):
    context = {
        'meta_title': 'پشتیبانی | ماهومه',
        'meta_description': 'راه‌های ارتباط با تیم پشتیبانی ماهومه.',
    }
    return render(request, 'core/support.html', context)


def project_detail(request, slug):
    project = get_object_or_404(Project, slug=slug, is_active=True)
    context = {
        'project': project,
        'meta_title': f'{project.name} | پروژه‌های ماهومه',
        'meta_description': project.short_description,
    }
    return render(request, 'core/project_detail.html', context)


def article_detail(request, slug):
    article = get_object_or_404(Article, slug=slug, is_active=True)
    context = {
        'article': article,
        'meta_title': f'{article.name} | مقالات ماهومه',
        'meta_description': article.short_description,
    }
    return render(request, 'core/article_detail.html', context)
