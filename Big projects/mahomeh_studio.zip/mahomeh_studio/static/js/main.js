document.addEventListener('DOMContentLoaded', function () {

  /* Mobile nav toggle ----------------------------------------------------- */
  var navToggle = document.getElementById('navToggle');
  var mainNav = document.getElementById('mainNav');
  if (navToggle && mainNav) {
    navToggle.addEventListener('click', function () {
      mainNav.classList.toggle('open');
    });
    // Close menu when a link inside it is tapped
    mainNav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () { mainNav.classList.remove('open'); });
    });
  }

  /* Home page auto slider --------------------------------------------------
     Cycles every N milliseconds (set via data-interval on #heroSlider,
     defaults to 5000ms). Works with any number of slides, including 0/1. */
  var slider = document.getElementById('heroSlider');
  if (slider) {
    var slides = slider.querySelectorAll('.slide');
    var dotsWrap = document.getElementById('slideDots');
    var interval = parseInt(slider.getAttribute('data-interval'), 10) || 5000;
    var current = 0;

    if (slides.length > 1) {
      if (dotsWrap) {
        slides.forEach(function (_, i) {
          var dot = document.createElement('span');
          dot.className = 'dot' + (i === 0 ? ' active' : '');
          dot.addEventListener('click', function () { goTo(i); });
          dotsWrap.appendChild(dot);
        });
      }

      function goTo(index) {
        slides[current].classList.remove('active');
        if (dotsWrap) dotsWrap.children[current].classList.remove('active');
        current = index;
        slides[current].classList.add('active');
        if (dotsWrap) dotsWrap.children[current].classList.add('active');
      }

      setInterval(function () {
        goTo((current + 1) % slides.length);
      }, interval);
    }
  }
});
